from __future__ import annotations

from typing import List, Optional, Tuple, Union, Dict, Any

import pandas as pd

from panda_data.config import get_config
from panda_data.core.service import fetch_dataframe
from panda_data.utils.common_utils import build_endpoint
from panda_data.utils.param_check_utils import (
    validate_param_types,
    validate_symbol_format,
    validate_no_duplicates,
    validate_date_format,
    validate_market,
    validate_stock_status,
    validate_date_range, validate_not_empty, validate_extra_params,
    validate_index_symbol_format, validate_index_status, validate_industry_code_format,
    validate_industry_level, validate_side_value, validate_margin_type_value, validate_rank_pair, validate_stock_type,
    validate_stock_info_market
)


config = get_config()
MULTI_ENDPOINT = config.get("JAVA_SERVICE_KLINE_ENDPOINT", "/multi")
PATH_GET_STOCK_DETAIL = config.get("JAVA_SERVICE_KLINE_PATH_GET_STOCK_DETAIL", "/getStockDetail")

INDEX_ENDPOINT = config.get("JAVA_SERVICE_INDEX_ENDPOINT", "/index")
PATH_GET_INDEX_SYMBOL = config.get("JAVA_SERVICE_INDEX_PATH_GET_SYMBOL", "/getIndexSymbolData")
PATH_GET_INDEX_INDICATOR = config.get("JAVA_SERVICE_INDEX_PATH_GET_INDICATOR", "/getIndexIndicatorData")
PATH_GET_INDEX_WEIGHTS = config.get("JAVA_SERVICE_INDEX_PATH_GET_WEIGHTS", "/getIndexWeightsData")

CONCEPT_ENDPOINT = config.get("JAVA_SERVICE_CONCEPT_ENDPOINT", "/concept")
PATH_GET_CONCEPT_LIST = config.get("JAVA_SERVICE_CONCEPT_PATH_GET_CONCEPT_LIST")
PATH_GET_CONCEPT_STOCK = config.get("JAVA_SERVICE_CONCEPT_PATH_GET_CONCEPT_STOCK")

INDUSTRY_ENDPOINT = config.get("JAVA_SERVICE_INDUSTRY_ENDPOINT", "/industry")
PATH_GET_INDUSTRY_STOCK = config.get("JAVA_SERVICE_INDUSTRY_PATH_GET_STOCK", "/getIndustryStockData")
PATH_GET_INDUSTRY_LIST = config.get("JAVA_SERVICE_INDUSTRY_PATH_GET_LIST", "/getIndustryList")
PATH_GET_STOCK_INDUSTRY = config.get("JAVA_SERVICE_INDUSTRY_PATH_GET_STOCK_INDUSTRY", "/getStockIndustry")

ABNORMAL_ENDPOINT = config.get("JAVA_SERVICE_ABNORMAL_ENDPOINT", "/abnormal")
PATH_GET_ABNORMAL = config.get("JAVA_SERVICE_ABNORMAL_PATH_GET_ABNORMAL_DATA", "/getAbnormalData")
PATH_GET_ABNORMAL_DETAIL = config.get("JAVA_SERVICE_ABNORMAL_PATH_GET_ABNORMAL_DETAIL", "/getAbnormalDetailData")

BUYBACK_ENDPOINT = config.get("JAVA_SERVICE_BUY_BACK_ENDPOINT", "/buyback")
PATH_GET_BUY_BACK_DATA = config.get("JAVA_SERVICE_BUY_BACK_PATH_GET_BUY_BACK_DATA", "/getBuyBackData")

STOCK_ENDPOINT = config.get("JAVA_SERVICE_SECURITIES_MARGIN_ENDPOINT", "/stock")
PATH_GET_SECURITIES_MARGIN = config.get("JAVA_SERVICE_SECURITIES_MARGIN_PATH_GET_MARGIN", "/getSecuritiesMarginData")
PATH_GET_STOCK_CONNECT_DATA = config.get("JAVA_SERVICE_STOCK_CONNECT_PATH_GET_STOCK_CONNECT_DATA",
                                         "/getStockConnectData")
PATH_GET_INVESTOR_ACTIVITIES = config.get("JAVA_SERVICE_STOCK_PATH_GET_INVESTOR_ACTIVITIES", "/getStockInvestorData")
PATH_GET_RESTRICTED_DETAILS = config.get("JAVA_SERVICE_STOCK_PATH_GET_RESTRICTED_DETAILS", "/getStockRestrictedData")
PATH_GET_STOCK_CASH_DIVIDEND = config.get(
    "JAVA_SERVICE_STOCK_PATH_GET_STOCK_CASH_DIVIDEND",
    "/getStockCashDividendData"
)
PATH_GET_STOCK_DIVIDEND_INFO = config.get(
    "JAVA_SERVICE_STOCK_PATH_GET_STOCK_DIVIDEND_INFO",
    "/getStockDividendInfoData",
)
PATH_GET_STOCK_SPLIT_INFO = config.get(
    "JAVA_SERVICE_STOCK_PATH_GET_STOCK_SPLIT_INFO",
    "/getStockSplitInfoData",
)
PATH_GET_STOCK_DIVIDEND_AMOUNT = config.get(
    "JAVA_SERVICE_STOCK_PATH_GET_STOCK_DIVIDEND_AMOUNT",
    "/getStockDividendAmountData",
)
PATH_GET_STOCK_PRIVATE_PLACEMENT = config.get(
    "JAVA_SERVICE_STOCK_PATH_GET_STOCK_PRIVATE_PLACEMENT",
    "/getStockPrivatePlacementData",
)
PATH_GET_STOCK_ALLOTMENT = config.get(
    "JAVA_SERVICE_STOCK_PATH_GET_STOCK_ALLOTMENT",
    "/getStockAllotmentData",
)
PATH_GET_HOLDER_NUMBER = config.get("JAVA_SERVICE_STOCK_PATH_GET_HOLDER_NUMBER", "/getStockHolderNumberData")
PATH_GET_MAIN_SHAREHOLDER = config.get("JAVA_SERVICE_STOCK_PATH_GET_MAIN_SHAREHOLDER", "/getStockMainHolderData")
PATH_GET_BLOCK_TRADE = config.get("JAVA_SERVICE_STOCK_PATH_GET_BLOCK_TRADE", "/getStockBlockTradeData")
PATH_GET_STOCK_SHARES = config.get("JAVA_SERVICE_STOCK_PATH_GET_SHARES", "/getStockShareData")
PATH_GET_STOCK_SHAREHOLDER_TRADING_PLAN = config.get("JAVA_SERVICE_STOCK_PATH_GET_STOCK_SHAREHOLDER_TRADING_PLAN", "/getStockShareholderTradingPlanData")
PATH_GET_STOCK_EQUITY_PLEDGE = config.get("JAVA_SERVICE_STOCK_PATH_GET_STOCK_EQUITY_PLEDGE", "/getStockEquityPledgeData")
PATH_GET_STOCK_EQUITY_PLEDGE_STAT = config.get("JAVA_SERVICE_STOCK_PATH_GET_STOCK_EQUITY_PLEDGE_STAT", "/getStockEquityPledgeStatData")

def _normalise_symbols(symbol: Optional[Union[str, List[str]]]) -> Optional[List[str]]:
    if symbol is None or symbol == "":
        return None
    if isinstance(symbol, list):
        return symbol
    return [symbol]

def _normalise_list(value: Optional[Union[str, List[str]]]) -> Optional[List[str]]:
    if value is None:
        return None
    if isinstance(value, list):
        return [item for item in value if item not in (None, "")]
    return [value] if value != "" else None

def _normalize_to_list(value: Union[str, List[str]]) -> List[str]:
    return value if isinstance(value, list) else [value]

def _build_payload_lhb(
        *,
        symbol: Optional[Union[str, List[str]]] = None,
        type: Optional[Union[str, List[str]]] = None,
        start_date: Optional[str] = None,
        end_date: Optional[str] = None,
        fields: Optional[List[str]] = None,
) -> Dict[str, Any]:
    payload: Dict[str, Any] = {}
    if symbol is not None:
        payload["symbol"] = _normalize_to_list(symbol)
    if type is not None:
        payload["type"] = _normalize_to_list(type)
    if start_date is not None:
        payload["startDate"] = start_date
    if end_date is not None:
        payload["endDate"] = end_date
    if fields:
        payload["fields"] = fields
    return payload

def get_stock_detail(
        symbol: Optional[Union[str, List[str]]] = "",
        fields: Optional[Union[str, List[str]]] = None,
        market: Optional[str] = "cn",
        status: Optional[int] = None,
        **kwargs
) -> pd.DataFrame:

    validate_extra_params(kwargs)

    # 验证参数类型
    params = {
        'symbol': symbol,
        'fields': fields
    }

    type_config = {
        'symbol': str,
        'fields': str
    }

    validated_params = validate_param_types(
        params,
        type_config,
        allowed_list_params=['symbol', 'fields']
    )

    # 验证symbol格式（根据market类型）
    if validated_params['symbol'] is not None and validated_params['symbol'] != [""] and validated_params[
        'symbol'] != []:
        # 验证symbol列表中是否有重复值
        validate_no_duplicates(validated_params['symbol'], 'symbol')

        # 根据market类型验证symbol格式
        validated_market = validate_market(market, "market")
        if validated_market == "cn":
            validate_symbol_format(validated_params['symbol'])
        # 对于hk和us，只检查重复，不检查格式

    # 验证fields列表中是否有重复值
    if validated_params['fields'] is not None:
        validate_no_duplicates(validated_params['fields'], 'fields')

    # 验证market参数
    validated_market = validate_market(market, "market")

    # 验证status参数
    validated_status = validate_stock_status(status, "status") if status is not None else status

    payload = {"market": validated_market}

    symbols = _normalise_symbols(validated_params['symbol'] if validated_params['symbol'] != [""] else None)
    if symbols is not None:
        payload["symbol"] = symbols
    if validated_params['fields']:
        payload["fields"] = validated_params['fields']
    if validated_status is not None:
        payload["status"] = validated_status

    df = fetch_dataframe(build_endpoint(MULTI_ENDPOINT, PATH_GET_STOCK_DETAIL), payload=payload)
    if not df.empty and "symbol" in df.columns:
        df = df[df["symbol"].str.upper() != "UNKNOWN"]
    return df

def get_index_detail(
        symbol: Optional[Union[str, List[str]]] = None,
        status: Optional[int] = None,
        fields: Optional[Union[str, List[str]]] = None,
        **kwargs
) -> pd.DataFrame:
    payload = {}

    validate_extra_params(kwargs)

    # 验证参数类型
    params = {
        'symbol': symbol,
        'fields': fields
    }

    type_config = {
        'symbol': str,
        'fields': str
    }

    validated_params = validate_param_types(
        params,
        type_config,
        allowed_list_params=['symbol', 'fields']
    )

    # 验证symbol格式（指数格式）
    if validated_params['symbol'] is not None:
        validate_index_symbol_format(validated_params['symbol'])
        # 验证symbol列表中是否有重复值
        validate_no_duplicates(validated_params['symbol'], 'symbol')

    # 验证fields列表中是否有重复值（空值会被正确处理）
    if validated_params['fields'] is not None:
        validate_no_duplicates(validated_params['fields'], 'fields')

    # 验证status参数
    if status is not None:
        validated_status = validate_index_status(status, "status")
    else:
        validated_status = status

    symbols = _normalise_list(validated_params['symbol'])
    if symbols is not None:
        payload["symbol"] = symbols
    if validated_status is not None:
        payload["status"] = validated_status
    if validated_params['fields']:
        payload["fields"] = validated_params['fields']

    df = fetch_dataframe(build_endpoint(INDEX_ENDPOINT, PATH_GET_INDEX_SYMBOL), payload=payload)
    if not df.empty and {"symbol"}.issubset(df.columns):
        cols = df.columns.tolist()
        priority_cols = ["symbol"]
        other_cols = [col for col in cols if col not in priority_cols]
        df = df[priority_cols + other_cols]
    return df

def _build_payload(
    *,
    concept: Optional[Union[str, List[str]]] = None,
    start_date: Optional[str] = None,
    end_date: Optional[str] = None,
    fields: Optional[Union[str, List[str]]] = None,
    date: Optional[str] = None
) -> Dict[str, Any]:
    payload: Dict[str, Any] = {}
    concept_list = _normalise_list(concept)
    if concept_list is not None:
        payload["concept"] = concept_list
    if start_date is not None:
        payload["startDate"] = start_date
    if end_date is not None:
        payload["endDate"] = end_date
    if fields:
        payload["fields"] = fields
    if date:
        payload["date"] = date
    return payload


def get_concept_list(
        concept: Optional[Union[str, List[str]]] = None,
        start_date: Optional[str] = None,
        end_date: Optional[str] = None,
        **kwargs
) -> pd.DataFrame:
    """
    获取概念列表
    """
    validate_extra_params(kwargs)
    # 验证参数类型
    params = {
        'concept': concept
    }

    type_config = {
        'concept': str
    }

    validated_params = validate_param_types(
        params,
        type_config,
        allowed_list_params=['concept']
    )

    # 验证concept列表中是否有重复值（空值会被正确处理）
    if validated_params['concept'] is not None:
        validate_no_duplicates(validated_params['concept'], 'concept')

    # 验证日期格式
    validated_start_date = validate_date_format(start_date, "start_date")
    validated_end_date = validate_date_format(end_date, "end_date")

    # 验证日期范围
    validate_date_range(validated_start_date, validated_end_date)

    payload = _build_payload(
        concept=validated_params['concept'],
        start_date=validated_start_date,
        end_date=validated_end_date
    )

    df = fetch_dataframe(build_endpoint(CONCEPT_ENDPOINT, PATH_GET_CONCEPT_LIST), payload=payload)
    if not df.empty and {"name", "date"}.issubset(df.columns):
        cols = df.columns.tolist()
        priority_cols = ["name", "date"]
        other_cols = [col for col in cols if col not in priority_cols]
        df = df[priority_cols + other_cols]
    return df


def get_concept_constituents(
        concept: Optional[Union[str, List[str]]] = None,
        concept_stock: Optional[Union[str, List[str]]] = None,
        start_date: Optional[str] = None,
        end_date: Optional[str] = None,
        fields: Optional[Union[str, List[str]]] = None,
        date: Optional[str] = None,
        **kwargs
) -> pd.DataFrame:
    """
    获取概念成分股信息
    """
    validate_extra_params(kwargs)
    # 验证参数类型
    params = {
        'concept': concept,
        'concept_stock': concept_stock,
        'fields': fields
    }

    type_config = {
        'concept': str,
        'concept_stock': str,
        'fields': str
    }

    validated_params = validate_param_types(
        params,
        type_config,
        allowed_list_params=['concept', 'fields', 'concept_stock']
    )

    # 验证concept_stock格式（空值会被正确处理）
    if validated_params['concept_stock'] is not None and validated_params['concept_stock'] != "":
        # concept_stock 类似 symbol 格式验证
        temp_result = [validated_params['concept_stock']] if isinstance(validated_params['concept_stock'], str) else \
        validated_params['concept_stock']
        validate_symbol_format(temp_result)
        # 验证concept_stock是否有重复值
        validate_no_duplicates(temp_result, 'concept_stock')

    # 验证concept列表中是否有重复值（空值会被正确处理）
    if validated_params['concept'] is not None:
        validate_no_duplicates(validated_params['concept'], 'concept')

    # 验证fields列表中是否有重复值（空值会被正确处理）
    if validated_params['fields'] is not None:
        validate_no_duplicates(validated_params['fields'], 'fields')

    # 验证日期格式
    validated_start_date = validate_date_format(start_date, "start_date")
    validated_end_date = validate_date_format(end_date, "end_date")
    validated_date = validate_date_format(date, "date")

    # 验证日期范围
    validate_date_range(validated_start_date, validated_end_date)

    payload = _build_payload(
        concept=validated_params['concept'],
        start_date=validated_start_date,
        end_date=validated_end_date,
        fields=validated_params['fields'],
        date=validated_date
    )

    if validated_params['concept_stock'] is not None:
        payload["conceptStock"] = validated_params['concept_stock']

    df = fetch_dataframe(build_endpoint(CONCEPT_ENDPOINT, PATH_GET_CONCEPT_STOCK), payload=payload)
    if not df.empty and {"concept_stock", "date"}.issubset(df.columns):
        cols = df.columns.tolist()
        priority_cols = ["concept_stock", "date"]
        other_cols = [col for col in cols if col not in priority_cols]
        df = df[priority_cols + other_cols]
    return df


def get_industry_constituents(
        industry_code: Optional[Union[str, List[str]]] = None,
        stock_symbol: Optional[Union[str, List[str]]] = None,
        level: Optional[str] = None,
        fields: Optional[Union[str, List[str]]] = None
) -> pd.DataFrame:
    payload = {}

    # 验证参数类型
    params = {
        'industry_code': industry_code,
        'stock_symbol': stock_symbol,
        'level': level,
        'fields': fields
    }

    type_config = {
        'industry_code': str,
        'stock_symbol': str,
        'level': str,
        'fields': str
    }

    validated_params = validate_param_types(
        params,
        type_config,
        allowed_list_params=['industry_code', 'stock_symbol', 'fields']  # industry_code 和 stock_symbol 允许是列表
    )

    # 验证industry_code格式（6位数字格式）
    if validated_params['industry_code'] is not None:
        validate_industry_code_format(validated_params['industry_code'])
        # 验证industry_code列表中是否有重复值
        validate_no_duplicates(validated_params['industry_code'], 'industry_code')

    # 验证stock_symbol格式（6位数字格式）
    if validated_params['stock_symbol'] is not None:
        validate_symbol_format(validated_params['stock_symbol'])
        # 验证stock_symbol列表中是否有重复值
        validate_no_duplicates(validated_params['stock_symbol'], 'stock_symbol')

    # 验证level格式
    if validated_params['level'] is not None and validated_params['level'] != "":
        # 验证level格式
        temp_result = [validated_params['level']] if isinstance(validated_params['level'], str) else validated_params[
            'level']
        validate_industry_level(temp_result, 'level')

    # 验证fields列表中是否有重复值（空值会被正确处理）
    if validated_params['fields'] is not None:
        validate_no_duplicates(validated_params['fields'], 'fields')

    if validated_params['industry_code'] is not None:
        payload["industryCode"] = validated_params['industry_code']
    if validated_params['stock_symbol'] is not None:
        payload["stockSymbol"] = validated_params['stock_symbol']
    if validated_params['level'] is not None:
        payload["level"] = validated_params['level']
    if validated_params['fields']:
        payload["fields"] = validated_params['fields']

    df = fetch_dataframe(build_endpoint(INDUSTRY_ENDPOINT, PATH_GET_INDUSTRY_STOCK), payload=payload)
    if not df.empty and {"stock_symbol"}.issubset(df.columns):
        cols = df.columns.tolist()
        priority_cols = ["stock_symbol" ]
        other_cols = [col for col in cols if col not in priority_cols]
        df = df[priority_cols + other_cols]
    return df


def get_industry_detail(
        level: Optional[str] = "L1",
        fields: Optional[Union[str, List[str]]] = None,
        **kwargs
) -> pd.DataFrame:
    payload = {}

    validate_extra_params(kwargs)

    # 验证参数类型
    params = {
        'level': level,
        'fields': fields
    }

    type_config = {
        'level': str,
        'fields': str
    }

    validated_params = validate_param_types(
        params,
        type_config,
        allowed_list_params=['fields']  # 只有fields允许是列表，level只能是字符串
    )

    # 验证level格式（只支持字符串）
    if validated_params['level'] is not None:
        validate_industry_level(validated_params['level'], 'level')

    # 验证fields列表中是否有重复值（空值会被正确处理）
    if validated_params['fields'] is not None:
        validate_no_duplicates(validated_params['fields'], 'fields')

    if validated_params['level'] is not None:
        payload["level"] = validated_params['level']
    if validated_params['fields']:
        payload["fields"] = validated_params['fields']

    df = fetch_dataframe(build_endpoint(INDUSTRY_ENDPOINT, PATH_GET_INDUSTRY_LIST), payload=payload)
    if not df.empty and {"industry_code"}.issubset(df.columns):
        cols = df.columns.tolist()
        priority_cols = ["industry_code"]
        other_cols = [col for col in cols if col not in priority_cols]
        df = df[priority_cols + other_cols]
    return df


def get_stock_industry(
    stock_symbol: str,
    level: Optional[str] = "L1",
) -> pd.DataFrame:
    validate_not_empty(stock_symbol, 'stock_symbol')
    # 验证参数类型
    params = {
        'stock_symbol': stock_symbol,
        'level': level
    }

    type_config = {
        'stock_symbol': str,
        'level': str
    }

    validated_params = validate_param_types(
        params,
        type_config,
        allowed_list_params=[]  # 都不允许是列表
    )

    # 验证stock_symbol格式（标准股票格式）和非空
    if validated_params['stock_symbol'] is not None:
        # 验证股票symbol格式
        temp_result = [validated_params['stock_symbol']] if isinstance(validated_params['stock_symbol'], str) else validated_params['stock_symbol']
        validate_symbol_format(temp_result)

    # 验证level格式
    if validated_params['level'] is not None and validated_params['level'] != "":
        # 验证level格式
        temp_result = [validated_params['level']] if isinstance(validated_params['level'], str) else validated_params['level']
        validate_industry_level(temp_result, 'level')

    payload = {"stockSymbol": validated_params['stock_symbol']}
    if validated_params['level'] is not None:
        payload["level"] = validated_params['level']
    df = fetch_dataframe(build_endpoint(INDUSTRY_ENDPOINT, PATH_GET_STOCK_INDUSTRY), payload=payload)
    if not df.empty and {"stock_symbol"}.issubset(df.columns):
        cols = df.columns.tolist()
        priority_cols = ["stock_symbol"]
        other_cols = [col for col in cols if col not in priority_cols]
        df = df[priority_cols + other_cols]

    return df

def get_index_indicator(
        symbol: Optional[Union[str, List[str]]] = None,
        start_date: Optional[str] = None,
        end_date: Optional[str] = None,
        fields: Optional[Union[str, List[str]]] = None,
        **kwargs
) -> pd.DataFrame:
    payload = {}

    validate_extra_params(kwargs)

    # 验证参数类型
    params = {
        'symbol': symbol,
        'fields': fields
    }

    type_config = {
        'symbol': str,
        'fields': str
    }

    validated_params = validate_param_types(
        params,
        type_config,
        allowed_list_params=['symbol', 'fields']
    )

    # 验证symbol格式（指数格式）
    if validated_params['symbol'] is not None:
        validate_index_symbol_format(validated_params['symbol'])
        # 验证symbol列表中是否有重复值
        validate_no_duplicates(validated_params['symbol'], 'symbol')

    # 验证fields列表中是否有重复值（空值会被正确处理）
    if validated_params['fields'] is not None:
        validate_no_duplicates(validated_params['fields'], 'fields')

    # 验证日期格式
    validated_start_date = validate_date_format(start_date, "start_date")
    validated_end_date = validate_date_format(end_date, "end_date")

    # 验证日期范围
    validate_date_range(validated_start_date, validated_end_date)

    symbols = _normalise_list(validated_params['symbol'])
    if symbols is not None:
        payload["symbol"] = symbols
    if validated_start_date is not None:
        payload["startDate"] = validated_start_date
    if validated_end_date is not None:
        payload["endDate"] = validated_end_date
    if validated_params['fields']:
        payload["fields"] = validated_params['fields']

    df = fetch_dataframe(build_endpoint(INDEX_ENDPOINT, PATH_GET_INDEX_INDICATOR), payload=payload)
    if not df.empty and {"symbol", "date"}.issubset(df.columns):
        cols = df.columns.tolist()
        priority_cols = ["symbol", "date"]
        other_cols = [col for col in cols if col not in priority_cols]
        df = df[priority_cols + other_cols]
    return df


def get_index_weights(
        index_symbol: Optional[Union[str, List[str]]] = None,
        stock_symbol: Optional[Union[str, List[str]]] = None,
        start_date: str = None,
        end_date: str = None,
        fields: Optional[Union[str, List[str]]] = None,
        **kwargs
) -> pd.DataFrame:
    payload = {}

    validate_extra_params(kwargs)

    validate_not_empty(start_date, "start_date")
    validate_not_empty(end_date, "end_date")
    # 验证参数类型
    params = {
        'index_symbol': index_symbol,
        'stock_symbol': stock_symbol,
        'fields': fields
    }

    type_config = {
        'index_symbol': str,
        'stock_symbol': str,
        'fields': str
    }

    validated_params = validate_param_types(
        params,
        type_config,
        allowed_list_params=['index_symbol', 'stock_symbol', 'fields']
    )

    # 验证index_symbol格式（指数格式）
    if validated_params['index_symbol'] is not None:
        validate_index_symbol_format(validated_params['index_symbol'])
        # 验证index_symbol列表中是否有重复值
        validate_no_duplicates(validated_params['index_symbol'], 'index_symbol')

    # 验证stock_symbol格式（股票格式）
    if validated_params['stock_symbol'] is not None:
        validate_symbol_format(validated_params['stock_symbol'])
        # 验证stock_symbol列表中是否有重复值
        validate_no_duplicates(validated_params['stock_symbol'], 'stock_symbol')

    # 验证fields列表中是否有重复值（空值会被正确处理）
    if validated_params['fields'] is not None:
        validate_no_duplicates(validated_params['fields'], 'fields')

    # 验证日期格式
    validated_start_date = validate_date_format(start_date, "start_date")
    validated_end_date = validate_date_format(end_date, "end_date")

    # 验证日期范围
    validate_date_range(validated_start_date, validated_end_date)

    index_symbols = _normalise_list(validated_params['index_symbol'])
    if index_symbols is not None:
        payload["indexSymbol"] = index_symbols
    stock_symbols = _normalise_list(validated_params['stock_symbol'])
    if stock_symbols is not None:
        payload["stockSymbol"] = stock_symbols
    if validated_start_date is not None:
        payload["startDate"] = validated_start_date
    if validated_end_date is not None:
        payload["endDate"] = validated_end_date
    if validated_params['fields']:
        payload["fields"] = validated_params['fields']

    df = fetch_dataframe(build_endpoint(INDEX_ENDPOINT, PATH_GET_INDEX_WEIGHTS), payload=payload)
    if not df.empty and {"index_symbol","stock_symbol", "date"}.issubset(df.columns):
        cols = df.columns.tolist()
        priority_cols = ["index_symbol","stock_symbol", "date"]
        other_cols = [col for col in cols if col not in priority_cols]
        df = df[priority_cols + other_cols]
    return df

def get_lhb_list(
        symbol: Optional[Union[str, List[str]]] = None,
        type: Optional[Union[str, List[str]]] = None,
        start_date: Optional[str] = None,
        end_date: Optional[str] = None,
        fields: Optional[Union[str, List[str]]] = None,
        **kwargs
) -> pd.DataFrame:
    """
    获取龙虎榜异常数据
    """
    # 1. 检查额外参数
    validate_extra_params(kwargs)

    # 2. 验证参数类型
    params = {
        'symbol': symbol,
        'type': type,
        'fields': fields
    }

    type_config = {
        'symbol': str,
        'type': str,
        'fields': str
    }

    validated_params = validate_param_types(
        params,
        type_config,
        allowed_list_params=['symbol', 'type', 'fields']
    )

    # 3. 验证symbol格式（空值会被正确处理）
    if validated_params['symbol'] is not None:
        validate_symbol_format(validated_params['symbol'])
        # 验证symbol列表中是否有重复值
        validate_no_duplicates(validated_params['symbol'], 'symbol')

    # 4. 验证type列表中是否有重复值（空值会被正确处理）
    if validated_params['type'] is not None:
        validate_no_duplicates(validated_params['type'], 'type')

    # 5. 验证fields列表中是否有重复值（空值会被正确处理）
    if validated_params['fields'] is not None:
        validate_no_duplicates(validated_params['fields'], 'fields')

    # 6. 验证日期格式
    validated_start_date = validate_date_format(start_date, "start_date")
    validated_end_date = validate_date_format(end_date, "end_date")

    # 7. 验证日期范围
    validate_date_range(validated_start_date, validated_end_date)

    payload = _build_payload_lhb(
        symbol=validated_params['symbol'],
        type=validated_params['type'],
        start_date=validated_start_date,
        end_date=validated_end_date,
        fields=validated_params['fields']
    )

    df = fetch_dataframe(build_endpoint(ABNORMAL_ENDPOINT, PATH_GET_ABNORMAL), payload=payload)
    if not df.empty and {"symbol", "date"}.issubset(df.columns):
        # 将 symbol 和 date 列放在最前面
        cols = df.columns.tolist()
        priority_cols = ["symbol", "date"]
        other_cols = [col for col in cols if col not in priority_cols]
        df = df[priority_cols + other_cols]
    return df


def get_lhb_detail(
        symbol: Optional[Union[str, List[str]]] = None,
        type: Optional[Union[str, List[str]]] = None,
        start_date: str = None,
        end_date: str = None,
        side: Optional[str] = None,
        fields: Optional[Union[str, List[str]]] = None,
        **kwargs
) -> pd.DataFrame:
    """
    获取龙虎榜异常明细数据
    """
    # 1. 检查额外参数和非空
    validate_extra_params(kwargs)

    validate_not_empty(start_date, "start_date")
    validate_not_empty(end_date, "end_date")

    # 2. 验证参数类型
    params = {
        'symbol': symbol,
        'type': type,
        'side': side,
        'fields': fields
    }

    type_config = {
        'symbol': str,
        'type': str,
        'side': str,
        'fields': str
    }

    validated_params = validate_param_types(
        params,
        type_config,
        allowed_list_params=['symbol', 'type', 'fields']
    )

    # 3. 验证symbol格式（空值会被正确处理）
    if validated_params['symbol'] is not None:
        validate_symbol_format(validated_params['symbol'])
        # 验证symbol列表中是否有重复值
        validate_no_duplicates(validated_params['symbol'], 'symbol')

    # 4. 验证type列表中是否有重复值（空值会被正确处理）
    if validated_params['type'] is not None:
        validate_no_duplicates(validated_params['type'], 'type')

    # 5. 验证fields列表中是否有重复值（空值会被正确处理）
    if validated_params['fields'] is not None:
        validate_no_duplicates(validated_params['fields'], 'fields')

    # 6. 验证side参数值
    if validated_params['side'] is not None:
        validated_params['side'] = validate_side_value(validated_params['side'])

    # 7. 验证日期格式
    validated_start_date = validate_date_format(start_date, "start_date")
    validated_end_date = validate_date_format(end_date, "end_date")

    # 8. 验证日期范围
    validate_date_range(validated_start_date, validated_end_date)

    payload = _build_payload_lhb(
        symbol=validated_params['symbol'],
        type=validated_params['type'],
        start_date=validated_start_date,
        end_date=validated_end_date,
        fields=validated_params['fields']
    )

    if validated_params['side'] is not None:
        payload["side"] = validated_params['side']

    df = fetch_dataframe(build_endpoint(ABNORMAL_ENDPOINT, PATH_GET_ABNORMAL_DETAIL), payload=payload)
    if not df.empty and {"symbol", "date"}.issubset(df.columns):
        # 将 symbol 和 date 列放在最前面
        cols = df.columns.tolist()
        priority_cols = ["symbol", "date"]
        other_cols = [col for col in cols if col not in priority_cols]
        df = df[priority_cols + other_cols]
    return df

def get_repurchase(
    symbol: Optional[Union[str, List[str]]] = None,
    start_date: Optional[str] = None,
    end_date: Optional[str] = None,
    fields: Optional[Union[str, List[str]]] = None,
    **kwargs
) -> pd.DataFrame:
    """
    获取回购数据
    """
    validate_extra_params(kwargs)
    # 1. 验证参数类型
    params = {
        'symbol': symbol,
        'fields': fields
    }

    type_config = {
        'symbol': str,
        'fields': str
    }

    validated_params = validate_param_types(
        params,
        type_config,
        allowed_list_params=['symbol', 'fields']
    )

    # 2. 验证symbol格式（空值会被正确处理）
    if validated_params['symbol'] is not None:
        validate_symbol_format(validated_params['symbol'])
        # 验证symbol列表中是否有重复值
        validate_no_duplicates(validated_params['symbol'], 'symbol')

    # 3. 验证fields列表中是否有重复值（空值会被正确处理）
    if validated_params['fields'] is not None:
        validate_no_duplicates(validated_params['fields'], 'fields')

    # 4. 验证日期格式
    validated_start_date = validate_date_format(start_date, "start_date")
    validated_end_date = validate_date_format(end_date, "end_date")

    # 5. 验证日期范围
    validate_date_range(validated_start_date, validated_end_date)

    payload = {}
    normalised_symbol = _normalise_symbols(validated_params['symbol'])
    if normalised_symbol is not None:
        payload["symbol"] = normalised_symbol
    if validated_start_date is not None:
        payload["startDate"] = validated_start_date
    if validated_end_date is not None:
        payload["endDate"] = validated_end_date
    if validated_params['fields']:
        payload["fields"] = validated_params['fields']

    df = fetch_dataframe(build_endpoint(BUYBACK_ENDPOINT, PATH_GET_BUY_BACK_DATA), payload=payload)
    if not df.empty and {"symbol", "date"}.issubset(df.columns):
        # 将 symbol 和 date 列放在最前面
        cols = df.columns.tolist()
        priority_cols = ["symbol", "date"]
        other_cols = [col for col in cols if col not in priority_cols]
        df = df[priority_cols + other_cols]
    return df

def get_margin(
    symbol: Optional[Union[str, List[str]]] = None,
    start_date: str = None,
    end_date: str = None,
    margin_type: Optional[str] = None,
    fields: Optional[Union[str, List[str]]] = None,
    **kwargs
) -> pd.DataFrame:
    # 1. 检查额外参数和必填
    validate_extra_params(kwargs)

    validate_not_empty(start_date, "start_date")
    validate_not_empty(end_date, "end_date")
    # 2. 验证参数类型
    params = {
        'symbol': symbol,
        'margin_type': margin_type,
        'fields': fields
    }

    type_config = {
        'symbol': str,
        'margin_type': str,
        'fields': str
    }

    validated_params = validate_param_types(
        params,
        type_config,
        allowed_list_params=['symbol', 'fields']
    )

    # 3. 验证symbol格式（空值会被正确处理）
    if validated_params['symbol'] is not None:
        validate_symbol_format(validated_params['symbol'])
        # 验证symbol列表中是否有重复值
        validate_no_duplicates(validated_params['symbol'], 'symbol')

    # 4. 验证fields列表中是否有重复值（空值会被正确处理）
    if validated_params['fields'] is not None:
        validate_no_duplicates(validated_params['fields'], 'fields')

    # 5. 验证margin_type参数值
    if validated_params['margin_type'] is not None:
        validated_params['margin_type'] = validate_margin_type_value(validated_params['margin_type'])

    # 6. 验证日期格式
    validated_start_date = validate_date_format(start_date, "start_date")
    validated_end_date = validate_date_format(end_date, "end_date")

    # 7. 验证日期范围
    validate_date_range(validated_start_date, validated_end_date)

    payload = {}
    symbols = _normalise_symbols(validated_params['symbol'])
    if symbols is not None:
        payload["symbol"] = symbols
    if validated_start_date is not None:
        payload["startDate"] = validated_start_date
    if validated_end_date is not None:
        payload["endDate"] = validated_end_date
    if validated_params['margin_type'] is not None:
        payload["marginType"] = validated_params['margin_type']
    if validated_params['fields']:
        payload["fields"] = validated_params['fields']

    df = fetch_dataframe(build_endpoint(STOCK_ENDPOINT, PATH_GET_SECURITIES_MARGIN), payload=payload)
    if not df.empty and {"symbol", "date"}.issubset(df.columns):
        cols = df.columns.tolist()
        priority_cols = ["symbol", "date"]
        other_cols = [col for col in cols if col not in priority_cols]
        df = df[priority_cols + other_cols]
    return df

def get_hsgt_hold(
        symbol: Optional[Union[str, List[str]]] = None,
        start_date: str = None,
        end_date: str = None,
        fields: Optional[Union[str, List[str]]] = None,
        **kwargs
) -> pd.DataFrame:
    # 1. 检查额外参数
    validate_extra_params(kwargs)

    validate_not_empty(start_date, "start_date")
    validate_not_empty(end_date, "end_date")

    # 2. 验证参数类型
    params = {
        'symbol': symbol,
        'fields': fields
    }

    type_config = {
        'symbol': str,
        'fields': str
    }

    validated_params = validate_param_types(
        params,
        type_config,
        allowed_list_params=['symbol', 'fields']
    )

    # 3. 验证symbol格式（空值会被正确处理）
    if validated_params['symbol'] is not None:
        validate_symbol_format(validated_params['symbol'])
        # 验证symbol列表中是否有重复值
        validate_no_duplicates(validated_params['symbol'], 'symbol')

    # 4. 验证fields列表中是否有重复值（空值会被正确处理）
    if validated_params['fields'] is not None:
        validate_no_duplicates(validated_params['fields'], 'fields')

    # 5. 验证日期格式
    validated_start_date = validate_date_format(start_date, "start_date")
    validated_end_date = validate_date_format(end_date, "end_date")

    # 6. 验证日期范围
    validate_date_range(validated_start_date, validated_end_date)

    payload = {}
    symbols = _normalise_symbols(validated_params['symbol'])
    if symbols is not None:
        payload["symbol"] = symbols
    if validated_start_date is not None:
        payload["startDate"] = validated_start_date
    if validated_end_date is not None:
        payload["endDate"] = validated_end_date
    if validated_params['fields']:
        payload["fields"] = validated_params['fields']
    df = fetch_dataframe(build_endpoint(STOCK_ENDPOINT, PATH_GET_STOCK_CONNECT_DATA), payload=payload)
    if not df.empty and {"symbol", "date"}.issubset(df.columns):
        cols = df.columns.tolist()
        priority_cols = ["symbol", "date"]
        other_cols = [col for col in cols if col not in priority_cols]
        df = df[priority_cols + other_cols]

    return df

def get_investor_activity(
    symbol: Optional[Union[str, List[str]]] = None,
    start_date: str = None,
    end_date: str = None,
    fields: Optional[Union[str, List[str]]] = None,
    **kwargs
) -> pd.DataFrame:
    # 1. 检查额外参数
    validate_extra_params(kwargs)

    validate_not_empty(start_date, "start_date")
    validate_not_empty(end_date, "end_date")

    # 2. 验证参数类型
    params = {
        'symbol': symbol,
        'fields': fields
    }

    type_config = {
        'symbol': str,
        'fields': str
    }

    validated_params = validate_param_types(
        params,
        type_config,
        allowed_list_params=['symbol', 'fields']
    )

    # 3. 验证symbol格式（空值会被正确处理）
    if validated_params['symbol'] is not None:
        validate_symbol_format(validated_params['symbol'])
        # 验证symbol列表中是否有重复值
        validate_no_duplicates(validated_params['symbol'], 'symbol')

    # 4. 验证fields列表中是否有重复值（空值会被正确处理）
    if validated_params['fields'] is not None:
        validate_no_duplicates(validated_params['fields'], 'fields')

    # 5. 验证日期格式
    validated_start_date = validate_date_format(start_date, "start_date")
    validated_end_date = validate_date_format(end_date, "end_date")

    # 6. 验证日期范围
    validate_date_range(validated_start_date, validated_end_date)

    payload = {}
    symbols = _normalise_list(validated_params['symbol'])
    if symbols is not None:
        payload["symbol"] = symbols
    if validated_start_date:
        payload["startDate"] = validated_start_date
    if validated_end_date:
        payload["endDate"] = validated_end_date
    if validated_params['fields']:
        payload["fields"] = validated_params['fields']
    df = fetch_dataframe(build_endpoint(STOCK_ENDPOINT, PATH_GET_INVESTOR_ACTIVITIES), payload=payload)
    if not df.empty and {"symbol", "date"}.issubset(df.columns):
        cols = df.columns.tolist()
        priority_cols = ["symbol", "date"]
        other_cols = [col for col in cols if col not in priority_cols]
        df = df[priority_cols + other_cols]
    return df


def get_restricted_list(
    symbol: Optional[Union[str, List[str]]] = None,
    start_date: str = None,
    end_date: str = None,
    market: Optional[str] = "cn",
    fields: Optional[Union[str, List[str]]] = None,
    **kwargs
) -> pd.DataFrame:
    # 1. 检查额外参数
    validate_extra_params(kwargs)

    validate_not_empty(start_date, "start_date")
    validate_not_empty(end_date, "end_date")

    # 2. 验证参数类型
    params = {
        'symbol': symbol,
        'market': market,
        'fields': fields
    }

    type_config = {
        'symbol': str,
        'market': str,
        'fields': str
    }

    validated_params = validate_param_types(
        params,
        type_config,
        allowed_list_params=['symbol', 'fields']
    )

    # 3. 验证symbol格式（空值会被正确处理）
    if validated_params['symbol'] is not None:
        validate_symbol_format(validated_params['symbol'])
        # 验证symbol列表中是否有重复值
        validate_no_duplicates(validated_params['symbol'], 'symbol')

    # 4. 验证fields列表中是否有重复值（空值会被正确处理）
    if validated_params['fields'] is not None:
        validate_no_duplicates(validated_params['fields'], 'fields')

    # 5. 验证市场参数
    if validated_params['market'] is not None:
        validated_params['market'] = validate_stock_info_market(validated_params['market'])

    # 6. 验证日期格式
    validated_start_date = validate_date_format(start_date, "start_date")
    validated_end_date = validate_date_format(end_date, "end_date")

    # 7. 验证日期范围
    validate_date_range(validated_start_date, validated_end_date)

    payload = {"market": validated_params['market']}
    symbols = _normalise_list(validated_params['symbol'])
    if symbols is not None:
        payload["symbol"] = symbols
    if validated_start_date:
        payload["startDate"] = validated_start_date
    if validated_end_date:
        payload["endDate"] = validated_end_date
    if validated_params['fields']:
        payload["fields"] = validated_params['fields']
    df = fetch_dataframe(build_endpoint(STOCK_ENDPOINT, PATH_GET_RESTRICTED_DETAILS), payload=payload)
    if not df.empty and {"symbol", "date"}.issubset(df.columns):
        cols = df.columns.tolist()
        priority_cols = ["symbol", "date"]
        other_cols = [col for col in cols if col not in priority_cols]
        df = df[priority_cols + other_cols]
    return df


def get_stock_cash_dividend(
    symbol: Optional[Union[str, List[str]]] = None,
    start_date: str = None,
    end_date: str = None,
    market: Optional[str] = "cn",
    fields: Optional[Union[str, List[str]]] = None,
    **kwargs
) -> pd.DataFrame:
    # 1. 检查额外参数
    validate_extra_params(kwargs)

    validate_not_empty(start_date, "start_date")
    validate_not_empty(end_date, "end_date")

    # 2. 验证参数类型
    params = {
        'symbol': symbol,
        'market': market,
        'fields': fields
    }

    type_config = {
        'symbol': str,
        'market': str,
        'fields': str
    }

    validated_params = validate_param_types(
        params,
        type_config,
        allowed_list_params=['symbol', 'fields']
    )

    # 3. 验证symbol格式
    if validated_params['symbol'] is not None:
        validate_symbol_format(validated_params['symbol'])
        validate_no_duplicates(validated_params['symbol'], 'symbol')

    # 4. 验证fields列表中是否有重复值
    if validated_params['fields'] is not None:
        validate_no_duplicates(validated_params['fields'], 'fields')

    # 5. 验证市场参数
    if validated_params['market'] is not None:
        validated_params['market'] = validate_stock_info_market(validated_params['market'])

    # 6. 验证日期格式
    validated_start_date = validate_date_format(start_date, "start_date")
    validated_end_date = validate_date_format(end_date, "end_date")

    # 7. 验证日期范围
    validate_date_range(validated_start_date, validated_end_date)

    payload = {"market": validated_params['market']}
    symbols = _normalise_list(validated_params['symbol'])
    if symbols is not None:
        payload["symbol"] = symbols
    if validated_start_date:
        payload["startDate"] = validated_start_date
    if validated_end_date:
        payload["endDate"] = validated_end_date
    if validated_params['fields']:
        payload["fields"] = validated_params['fields']
    df = fetch_dataframe(build_endpoint(STOCK_ENDPOINT, PATH_GET_STOCK_CASH_DIVIDEND), payload=payload)
    if not df.empty and {"symbol", "announcement_date"}.issubset(df.columns):
        cols = df.columns.tolist()
        priority_cols = ["symbol", "announcement_date"]
        other_cols = [col for col in cols if col not in priority_cols]
        df = df[priority_cols + other_cols]
    return df


def get_stock_dividend(
    symbol: Optional[Union[str, List[str]]] = None,
    start_date: str = None,
    end_date: str = None,
    market: Optional[str] = "cn",
    fields: Optional[Union[str, List[str]]] = None,
    **kwargs
) -> pd.DataFrame:
    # 1. 检查额外参数
    validate_extra_params(kwargs)

    validate_not_empty(start_date, "start_date")
    validate_not_empty(end_date, "end_date")

    # 2. 验证参数类型
    params = {
        'symbol': symbol,
        'market': market,
        'fields': fields
    }

    type_config = {
        'symbol': str,
        'market': str,
        'fields': str
    }

    validated_params = validate_param_types(
        params,
        type_config,
        allowed_list_params=['symbol', 'fields']
    )

    # 3. 验证symbol格式
    if validated_params['symbol'] is not None:
        validate_symbol_format(validated_params['symbol'])
        validate_no_duplicates(validated_params['symbol'], 'symbol')

    # 4. 验证fields列表中是否有重复值
    if validated_params['fields'] is not None:
        validate_no_duplicates(validated_params['fields'], 'fields')

    # 5. 验证市场参数
    if validated_params['market'] is not None:
        validated_params['market'] = validate_stock_info_market(validated_params['market'])

    # 6. 验证日期格式
    validated_start_date = validate_date_format(start_date, "start_date")
    validated_end_date = validate_date_format(end_date, "end_date")

    # 7. 验证日期范围
    validate_date_range(validated_start_date, validated_end_date)

    payload = {"market": validated_params['market']}
    symbols = _normalise_list(validated_params['symbol'])
    if symbols is not None:
        payload["symbol"] = symbols
    if validated_start_date:
        payload["startDate"] = validated_start_date
    if validated_end_date:
        payload["endDate"] = validated_end_date
    if validated_params['fields']:
        payload["fields"] = validated_params['fields']
    df = fetch_dataframe(build_endpoint(STOCK_ENDPOINT, PATH_GET_STOCK_DIVIDEND_INFO), payload=payload)
    if not df.empty and {"symbol", "announcement_date"}.issubset(df.columns):
        cols = df.columns.tolist()
        priority_cols = ["symbol", "announcement_date"]
        other_cols = [col for col in cols if col not in priority_cols]
        df = df[priority_cols + other_cols]
    return df


def get_stock_split(
    symbol: Optional[Union[str, List[str]]] = None,
    start_date: str = None,
    end_date: str = None,
    market: Optional[str] = "cn",
    fields: Optional[Union[str, List[str]]] = None,
    **kwargs
) -> pd.DataFrame:
    # 1. 检查额外参数
    validate_extra_params(kwargs)

    validate_not_empty(start_date, "start_date")
    validate_not_empty(end_date, "end_date")

    # 2. 验证参数类型
    params = {
        'symbol': symbol,
        'market': market,
        'fields': fields
    }

    type_config = {
        'symbol': str,
        'market': str,
        'fields': str
    }

    validated_params = validate_param_types(
        params,
        type_config,
        allowed_list_params=['symbol', 'fields']
    )

    # 3. 验证symbol格式
    if validated_params['symbol'] is not None:
        validate_symbol_format(validated_params['symbol'])
        validate_no_duplicates(validated_params['symbol'], 'symbol')

    # 4. 验证fields列表中是否有重复值
    if validated_params['fields'] is not None:
        validate_no_duplicates(validated_params['fields'], 'fields')

    # 5. 验证市场参数
    if validated_params['market'] is not None:
        validated_params['market'] = validate_stock_info_market(validated_params['market'])

    # 6. 验证日期格式
    validated_start_date = validate_date_format(start_date, "start_date")
    validated_end_date = validate_date_format(end_date, "end_date")

    # 7. 验证日期范围
    validate_date_range(validated_start_date, validated_end_date)

    payload = {"market": validated_params['market']}
    symbols = _normalise_list(validated_params['symbol'])
    if symbols is not None:
        payload["symbol"] = symbols
    if validated_start_date:
        payload["startDate"] = validated_start_date
    if validated_end_date:
        payload["endDate"] = validated_end_date
    if validated_params['fields']:
        payload["fields"] = validated_params['fields']
    df = fetch_dataframe(build_endpoint(STOCK_ENDPOINT, PATH_GET_STOCK_SPLIT_INFO), payload=payload)
    if not df.empty and {"symbol", "ex_date"}.issubset(df.columns):
        cols = df.columns.tolist()
        priority_cols = ["symbol", "ex_date"]
        other_cols = [col for col in cols if col not in priority_cols]
        df = df[priority_cols + other_cols]
    return df


def get_stock_dividend_amount(
    symbol: Optional[Union[str, List[str]]] = None,
    start_date: str = None,
    end_date: str = None,
    market: Optional[str] = "cn",
    fields: Optional[Union[str, List[str]]] = None,
    **kwargs
) -> pd.DataFrame:
    # 1. 检查额外参数
    validate_extra_params(kwargs)

    validate_not_empty(start_date, "start_date")
    validate_not_empty(end_date, "end_date")

    # 2. 验证参数类型
    params = {
        'symbol': symbol,
        'market': market,
        'fields': fields
    }

    type_config = {
        'symbol': str,
        'market': str,
        'fields': str
    }

    validated_params = validate_param_types(
        params,
        type_config,
        allowed_list_params=['symbol', 'fields']
    )

    # 3. 验证symbol格式
    if validated_params['symbol'] is not None:
        validate_symbol_format(validated_params['symbol'])
        validate_no_duplicates(validated_params['symbol'], 'symbol')

    # 4. 验证fields列表中是否有重复值
    if validated_params['fields'] is not None:
        validate_no_duplicates(validated_params['fields'], 'fields')

    # 5. 验证市场参数
    if validated_params['market'] is not None:
        validated_params['market'] = validate_stock_info_market(validated_params['market'])

    # 6. 验证日期格式
    validated_start_date = validate_date_format(start_date, "start_date")
    validated_end_date = validate_date_format(end_date, "end_date")

    # 7. 验证日期范围
    validate_date_range(validated_start_date, validated_end_date)

    payload = {"market": validated_params['market']}
    symbols = _normalise_list(validated_params['symbol'])
    if symbols is not None:
        payload["symbol"] = symbols
    if validated_start_date:
        payload["startDate"] = validated_start_date
    if validated_end_date:
        payload["endDate"] = validated_end_date
    if validated_params['fields']:
        payload["fields"] = validated_params['fields']
    df = fetch_dataframe(build_endpoint(STOCK_ENDPOINT, PATH_GET_STOCK_DIVIDEND_AMOUNT), payload=payload)
    if not df.empty and {"symbol", "announcement_date"}.issubset(df.columns):
        cols = df.columns.tolist()
        priority_cols = ["symbol", "announcement_date"]
        other_cols = [col for col in cols if col not in priority_cols]
        df = df[priority_cols + other_cols]
    return df


def get_stock_private_placement(
    symbol: Optional[Union[str, List[str]]] = None,
    start_date: str = None,
    end_date: str = None,
    market: Optional[str] = "cn",
    fields: Optional[Union[str, List[str]]] = None,
    **kwargs
) -> pd.DataFrame:
    # 1. 检查额外参数
    validate_extra_params(kwargs)

    validate_not_empty(start_date, "start_date")
    validate_not_empty(end_date, "end_date")

    # 2. 验证参数类型
    params = {
        'symbol': symbol,
        'market': market,
        'fields': fields
    }

    type_config = {
        'symbol': str,
        'market': str,
        'fields': str
    }

    validated_params = validate_param_types(
        params,
        type_config,
        allowed_list_params=['symbol', 'fields']
    )

    # 3. 验证symbol格式
    if validated_params['symbol'] is not None:
        validate_symbol_format(validated_params['symbol'])
        validate_no_duplicates(validated_params['symbol'], 'symbol')

    # 4. 验证fields列表中是否有重复值
    if validated_params['fields'] is not None:
        validate_no_duplicates(validated_params['fields'], 'fields')

    # 5. 验证市场参数
    if validated_params['market'] is not None:
        validated_params['market'] = validate_stock_info_market(validated_params['market'])

    # 6. 验证日期格式
    validated_start_date = validate_date_format(start_date, "start_date")
    validated_end_date = validate_date_format(end_date, "end_date")

    # 7. 验证日期范围
    validate_date_range(validated_start_date, validated_end_date)

    payload = {"market": validated_params['market']}
    symbols = _normalise_list(validated_params['symbol'])
    if symbols is not None:
        payload["symbol"] = symbols
    if validated_start_date:
        payload["startDate"] = validated_start_date
    if validated_end_date:
        payload["endDate"] = validated_end_date
    if validated_params['fields']:
        payload["fields"] = validated_params['fields']
    df = fetch_dataframe(build_endpoint(STOCK_ENDPOINT, PATH_GET_STOCK_PRIVATE_PLACEMENT), payload=payload)
    if not df.empty and {"symbol", "announcement_date"}.issubset(df.columns):
        cols = df.columns.tolist()
        priority_cols = ["symbol", "announcement_date"]
        other_cols = [col for col in cols if col not in priority_cols]
        df = df[priority_cols + other_cols]
    return df


def get_stock_allotment(
    symbol: Optional[Union[str, List[str]]] = None,
    start_date: str = None,
    end_date: str = None,
    market: Optional[str] = "cn",
    fields: Optional[Union[str, List[str]]] = None,
    **kwargs
) -> pd.DataFrame:
    # 1. 检查额外参数
    validate_extra_params(kwargs)

    validate_not_empty(start_date, "start_date")
    validate_not_empty(end_date, "end_date")

    # 2. 验证参数类型
    params = {
        'symbol': symbol,
        'market': market,
        'fields': fields
    }

    type_config = {
        'symbol': str,
        'market': str,
        'fields': str
    }

    validated_params = validate_param_types(
        params,
        type_config,
        allowed_list_params=['symbol', 'fields']
    )

    # 3. 验证symbol格式
    if validated_params['symbol'] is not None:
        validate_symbol_format(validated_params['symbol'])
        validate_no_duplicates(validated_params['symbol'], 'symbol')

    # 4. 验证fields列表中是否有重复值
    if validated_params['fields'] is not None:
        validate_no_duplicates(validated_params['fields'], 'fields')

    # 5. 验证市场参数
    if validated_params['market'] is not None:
        validated_params['market'] = validate_stock_info_market(validated_params['market'])

    # 6. 验证日期格式
    validated_start_date = validate_date_format(start_date, "start_date")
    validated_end_date = validate_date_format(end_date, "end_date")

    # 7. 验证日期范围
    validate_date_range(validated_start_date, validated_end_date)

    payload = {"market": validated_params['market']}
    symbols = _normalise_list(validated_params['symbol'])
    if symbols is not None:
        payload["symbol"] = symbols
    if validated_start_date:
        payload["startDate"] = validated_start_date
    if validated_end_date:
        payload["endDate"] = validated_end_date
    if validated_params['fields']:
        payload["fields"] = validated_params['fields']
    df = fetch_dataframe(build_endpoint(STOCK_ENDPOINT, PATH_GET_STOCK_ALLOTMENT), payload=payload)
    if not df.empty and {"symbol", "announcement_date"}.issubset(df.columns):
        cols = df.columns.tolist()
        priority_cols = ["symbol", "announcement_date"]
        other_cols = [col for col in cols if col not in priority_cols]
        df = df[priority_cols + other_cols]
    return df


def get_holder_count(
    symbol: Optional[Union[str, List[str]]] = None,
    start_date: Optional[str] = None,
    end_date: Optional[str] = None,
    fields: Optional[Union[str, List[str]]] = None,
    **kwargs
) -> pd.DataFrame:
    # 1. 检查额外参数
    validate_extra_params(kwargs)

    # 2. 验证参数类型
    params = {
        'symbol': symbol,
        'fields': fields
    }

    type_config = {
        'symbol': str,
        'fields': str
    }

    validated_params = validate_param_types(
        params,
        type_config,
        allowed_list_params=['symbol', 'fields']
    )

    # 3. 验证symbol格式（空值会被正确处理）
    if validated_params['symbol'] is not None:
        validate_symbol_format(validated_params['symbol'])
        # 验证symbol列表中是否有重复值
        validate_no_duplicates(validated_params['symbol'], 'symbol')

    # 4. 验证fields列表中是否有重复值（空值会被正确处理）
    if validated_params['fields'] is not None:
        validate_no_duplicates(validated_params['fields'], 'fields')

    # 5. 验证日期格式
    validated_start_date = validate_date_format(start_date, "start_date")
    validated_end_date = validate_date_format(end_date, "end_date")

    # 6. 验证日期范围
    validate_date_range(validated_start_date, validated_end_date)

    payload = {}
    symbols = _normalise_list(validated_params['symbol'])
    if symbols is not None:
        payload["symbol"] = symbols
    if validated_start_date:
        payload["startDate"] = validated_start_date
    if validated_end_date:
        payload["endDate"] = validated_end_date
    if validated_params['fields']:
        payload["fields"] = validated_params['fields']
    df = fetch_dataframe(build_endpoint(STOCK_ENDPOINT, PATH_GET_HOLDER_NUMBER), payload=payload)
    if not df.empty and {"symbol", "date"}.issubset(df.columns):
        cols = df.columns.tolist()
        priority_cols = ["symbol", "date"]
        other_cols = [col for col in cols if col not in priority_cols]
        df = df[priority_cols + other_cols]
    return df



def get_top_holders(
    symbol: Optional[Union[str, List[str]]] = None,
    start_date: str = None,
    end_date: str = None,
    start_rank: Optional[int] = None,
    end_rank: Optional[int] = None,
    stock_type: Optional[str] = None,
    market: Optional[str] = "cn",
    fields: Optional[Union[str, List[str]]] = None,
    **kwargs
) -> pd.DataFrame:
    # 1. 检查额外参数
    validate_extra_params(kwargs)

    validate_not_empty(start_date, "start_date")
    validate_not_empty(end_date, "end_date")

    # 2. 验证参数类型
    params = {
        'symbol': symbol,
        'start_rank': start_rank,
        'end_rank': end_rank,
        'stock_type': stock_type,
        'market': market,
        'fields': fields
    }

    type_config = {
        'symbol': str,
        'start_rank': int,
        'end_rank': int,
        'stock_type': str,
        'market': str,
        'fields': str
    }

    validated_params = validate_param_types(
        params,
        type_config,
        allowed_list_params=['symbol', 'fields']
    )

    # 3. 验证symbol格式（空值会被正确处理）
    if validated_params['symbol'] is not None:
        validate_symbol_format(validated_params['symbol'])
        # 验证symbol列表中是否有重复值
        validate_no_duplicates(validated_params['symbol'], 'symbol')

    # 4. 验证fields列表中是否有重复值（空值会被正确处理）
    if validated_params['fields'] is not None:
        validate_no_duplicates(validated_params['fields'], 'fields')

    # 5. 验证市场参数
    if validated_params['market'] is not None:
        validated_params['market'] = validate_stock_info_market(validated_params['market'])

    # 6. 验证股票类型参数
    if validated_params['stock_type'] is not None:
        validated_params['stock_type'] = validate_stock_type(validated_params['stock_type'])

    # 7. 验证排名参数对
    validate_rank_pair(validated_params['start_rank'], validated_params['end_rank'])

    # 8. 验证日期格式
    validated_start_date = validate_date_format(start_date, "start_date")
    validated_end_date = validate_date_format(end_date, "end_date")

    # 9. 验证日期范围
    validate_date_range(validated_start_date, validated_end_date)

    payload = {"market": validated_params['market']}
    symbols = _normalise_list(validated_params['symbol'])
    if symbols is not None:
        payload["symbol"] = symbols
    if validated_start_date:
        payload["startDate"] = validated_start_date
    if validated_end_date:
        payload["endDate"] = validated_end_date
    if validated_params['start_rank'] is not None:
        payload["startRank"] = validated_params['start_rank']
    if validated_params['end_rank'] is not None:
        payload["endRank"] = validated_params['end_rank']
    if validated_params['stock_type'] is not None:
        payload["stockType"] = validated_params['stock_type']
    if validated_params['fields']:
        payload["fields"] = validated_params['fields']
    df = fetch_dataframe(build_endpoint(STOCK_ENDPOINT, PATH_GET_MAIN_SHAREHOLDER), payload=payload)
    if not df.empty and {"symbol", "date"}.issubset(df.columns):
        cols = df.columns.tolist()
        priority_cols = ["symbol", "date"]
        other_cols = [col for col in cols if col not in priority_cols]
        df = df[priority_cols + other_cols]
    return df

def get_block_trade(
    symbol: Optional[Union[str, List[str]]] = None,
    start_date: Optional[str] = None,
    end_date: Optional[str] = None,
    fields: Optional[Union[str, List[str]]] = None,
    **kwargs
) -> pd.DataFrame:
    # 1. 检查额外参数
    validate_extra_params(kwargs)

    # 2. 验证参数类型
    params = {
        'symbol': symbol,
        'fields': fields
    }

    type_config = {
        'symbol': str,
        'fields': str
    }

    validated_params = validate_param_types(
        params,
        type_config,
        allowed_list_params=['symbol', 'fields']
    )

    # 3. 验证symbol格式（空值会被正确处理）
    if validated_params['symbol'] is not None:
        validate_symbol_format(validated_params['symbol'])
        # 验证symbol列表中是否有重复值
        validate_no_duplicates(validated_params['symbol'], 'symbol')

    # 4. 验证fields列表中是否有重复值（空值会被正确处理）、
    if validated_params['fields'] is not None:
        validate_no_duplicates(validated_params['fields'], 'fields')

    # 5. 验证日期格式
    validated_start_date = validate_date_format(start_date, "start_date")
    validated_end_date = validate_date_format(end_date, "end_date")

    # 6. 验证日期范围
    validate_date_range(validated_start_date, validated_end_date)

    payload = {}
    symbols = _normalise_list(validated_params['symbol'])
    if symbols is not None:
        payload["symbol"] = symbols
    if validated_start_date:
        payload["startDate"] = validated_start_date
    if validated_end_date:
        payload["endDate"] = validated_end_date
    if validated_params['fields']:
        payload["fields"] = validated_params['fields']
    df = fetch_dataframe(build_endpoint(STOCK_ENDPOINT, PATH_GET_BLOCK_TRADE), payload=payload)
    if not df.empty and {"symbol", "date"}.issubset(df.columns):
        cols = df.columns.tolist()
        priority_cols = ["symbol", "date"]
        other_cols = [col for col in cols if col not in priority_cols]
        df = df[priority_cols + other_cols]
    return df

def get_share_float(
    symbol: Optional[Union[str, List[str]]] = None,
    start_date: str = None,
    end_date: str = None,
    fields: Optional[Union[str, List[str]]] = None,
    **kwargs
) -> pd.DataFrame:
    # 1. 检查额外参数
    validate_extra_params(kwargs)

    validate_not_empty(start_date, "start_date")
    validate_not_empty(end_date, "end_date")

    # 2. 验证参数类型
    params = {
        'symbol': symbol,
        'fields': fields
    }

    type_config = {
        'symbol': str,
        'fields': str
    }

    validated_params = validate_param_types(
        params,
        type_config,
        allowed_list_params=['symbol', 'fields']
    )

    # 3. 验证symbol格式（空值会被正确处理）
    if validated_params['symbol'] is not None:
        validate_symbol_format(validated_params['symbol'])
        # 验证symbol列表中是否有重复值
        validate_no_duplicates(validated_params['symbol'], 'symbol')

    # 4. 验证fields列表中是否有重复值（空值会被正确处理）
    if validated_params['fields'] is not None:
        validate_no_duplicates(validated_params['fields'], 'fields')

    # 5. 验证日期格式
    validated_start_date = validate_date_format(start_date, "start_date")
    validated_end_date = validate_date_format(end_date, "end_date")

    # 6. 验证日期范围
    validate_date_range(validated_start_date, validated_end_date)

    payload = {}
    symbols = _normalise_list(validated_params['symbol'])
    if symbols is not None:
        payload["symbol"] = symbols
    if validated_start_date:
        payload["startDate"] = validated_start_date
    if validated_end_date:
        payload["endDate"] = validated_end_date
    if validated_params['fields']:
        payload["fields"] = validated_params['fields']
    df = fetch_dataframe(build_endpoint(STOCK_ENDPOINT, PATH_GET_STOCK_SHARES), payload=payload)
    if not df.empty and {"symbol", "date"}.issubset(df.columns):
        cols = df.columns.tolist()
        priority_cols = ["symbol", "date"]
        other_cols = [col for col in cols if col not in priority_cols]
        df = df[priority_cols + other_cols]
    return df

def get_stock_pledge(
    symbol: Optional[Union[str, List[str]]] = None,
    start_date: str = None,
    end_date: str = None,
    fields: Optional[Union[str, List[str]]] = None,
    **kwargs
) -> pd.DataFrame:
    # 1. 检查额外参数
    validate_extra_params(kwargs)

    validate_not_empty(start_date, "start_date")
    validate_not_empty(end_date, "end_date")

    # 2. 验证参数类型
    params = {
        'symbol': symbol,
        'fields': fields
    }

    type_config = {
        'symbol': str,
        'fields': str
    }

    validated_params = validate_param_types(
        params,
        type_config,
        allowed_list_params=['symbol', 'fields']
    )

    # 3. 验证symbol格式（空值会被正确处理）
    if validated_params['symbol'] is not None:
        validate_symbol_format(validated_params['symbol'])
        # 验证symbol列表中是否有重复值
        validate_no_duplicates(validated_params['symbol'], 'symbol')

    # 4. 验证fields列表中是否有重复值（空值会被正确处理）
    if validated_params['fields'] is not None:
        validate_no_duplicates(validated_params['fields'], 'fields')

    # 5. 验证日期格式
    validated_start_date = validate_date_format(start_date, "start_date")
    validated_end_date = validate_date_format(end_date, "end_date")

    # 6. 验证日期范围
    validate_date_range(validated_start_date, validated_end_date)

    payload = {}
    symbols = _normalise_list(validated_params['symbol'])
    if symbols is not None:
        payload["symbol"] = symbols
    if validated_start_date:
        payload["startDate"] = validated_start_date
    if validated_end_date:
        payload["endDate"] = validated_end_date
    if validated_params['fields']:
        payload["fields"] = validated_params['fields']
    df = fetch_dataframe(build_endpoint(STOCK_ENDPOINT, PATH_GET_STOCK_EQUITY_PLEDGE), payload=payload)
    if not df.empty and {"symbol", "publish_date"}.issubset(df.columns):
        cols = df.columns.tolist()
        priority_cols = ["symbol", "publish_date"]
        other_cols = [col for col in cols if col not in priority_cols]
        df = df[priority_cols + other_cols]
    return df

def get_stock_pledge_stat(
        start_date: str = None,
        end_date: str = None,
        fields: Optional[Union[str, List[str]]] = None,
        **kwargs
) -> pd.DataFrame:
    # 1. 检查额外参数
    validate_extra_params(kwargs)

    validate_not_empty(start_date, "start_date")
    validate_not_empty(end_date, "end_date")

    # 2. 验证参数类型
    params = {
        'fields': fields
    }

    type_config = {
        'fields': str
    }

    validated_params = validate_param_types(
        params,
        type_config,
        allowed_list_params=['fields']
    )

    # 3. 验证fields列表中是否有重复值（空值会被正确处理）
    if validated_params['fields'] is not None:
        validate_no_duplicates(validated_params['fields'], 'fields')

    # 4. 验证日期格式
    validated_start_date = validate_date_format(start_date, "start_date")
    validated_end_date = validate_date_format(end_date, "end_date")

    # 5. 验证日期范围
    validate_date_range(validated_start_date, validated_end_date)

    payload = {}
    if validated_start_date:
        payload["startDate"] = validated_start_date
    if validated_end_date:
        payload["endDate"] = validated_end_date
    if validated_params['fields']:
        payload["fields"] = validated_params['fields']

    df = fetch_dataframe(build_endpoint(STOCK_ENDPOINT, PATH_GET_STOCK_EQUITY_PLEDGE_STAT), payload=payload)

    if not df.empty:
        # 过滤掉stat_period列
        if "stat_period" in df.columns:
            df = df.drop(columns=["stat_period"])

        # 将 pledge_begin_date 和 pledge_end_date 列放在最前面
        cols = df.columns.tolist()
        priority_cols = ["pledge_begin_date", "pledge_end_date"]
        other_cols = [col for col in cols if col not in priority_cols]
        df = df[priority_cols + other_cols]

    return df

def get_stock_shareholder_change(
    symbol: Optional[Union[str, List[str]]] = None,
    start_date: str = None,
    end_date: str = None,
    fields: Optional[Union[str, List[str]]] = None,
    **kwargs
) -> pd.DataFrame:
    # 1. 检查额外参数
    validate_extra_params(kwargs)

    validate_not_empty(start_date, "start_date")
    validate_not_empty(end_date, "end_date")

    # 2. 验证参数类型
    params = {
        'symbol': symbol,
        'fields': fields
    }

    type_config = {
        'symbol': str,
        'fields': str
    }

    validated_params = validate_param_types(
        params,
        type_config,
        allowed_list_params=['symbol', 'fields']
    )

    # 3. 验证symbol格式（空值会被正确处理）
    if validated_params['symbol'] is not None:
        validate_symbol_format(validated_params['symbol'])
        # 验证symbol列表中是否有重复值
        validate_no_duplicates(validated_params['symbol'], 'symbol')

    # 4. 验证fields列表中是否有重复值（空值会被正确处理）
    if validated_params['fields'] is not None:
        validate_no_duplicates(validated_params['fields'], 'fields')

    # 5. 验证日期格式
    validated_start_date = validate_date_format(start_date, "start_date")
    validated_end_date = validate_date_format(end_date, "end_date")

    # 6. 验证日期范围
    validate_date_range(validated_start_date, validated_end_date)

    payload = {}
    symbols = _normalise_list(validated_params['symbol'])
    if symbols is not None:
        payload["symbol"] = symbols
    if validated_start_date:
        payload["startDate"] = validated_start_date
    if validated_end_date:
        payload["endDate"] = validated_end_date
    if validated_params['fields']:
        payload["fields"] = validated_params['fields']
    df = fetch_dataframe(build_endpoint(STOCK_ENDPOINT, PATH_GET_STOCK_SHAREHOLDER_TRADING_PLAN), payload=payload)
    if not df.empty and {"symbol", "info_date"}.issubset(df.columns):
        cols = df.columns.tolist()
        priority_cols = ["symbol", "info_date"]
        other_cols = [col for col in cols if col not in priority_cols]
        df = df[priority_cols + other_cols]
    return df