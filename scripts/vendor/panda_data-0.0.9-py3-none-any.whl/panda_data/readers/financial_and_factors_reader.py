from __future__ import annotations

from typing import Any, Dict, List, Optional, Union
from datetime import datetime

import pandas as pd

from panda_data.config import get_config
from panda_data.core.service import fetch_dataframe
from panda_data.exceptions import ServiceError, ServiceErrorCode
from panda_data.utils.common_utils import build_endpoint
from panda_data.utils.param_check_utils import (
    validate_date_format,
    validate_param_types,
    validate_symbol_format,
    validate_no_duplicates,
    validate_quarter_format,
    validate_quarter_range,
    validate_bool_type, validate_quarter_date_combination, validate_extra_params, validate_date_range,
    validate_stock_info_market, validate_not_empty, validate_factor_type, validate_future_symbol_format,
    validate_index_component, validate_date_interval, validate_indicator, validate_quarter_interval
)

config = get_config()
FINA_ENDPOINT = config.get("JAVA_SERVICE_FINANCIAL_ENDPOINT", "/financial")
PATH_GET_FINANCIAL_FORECAST = config.get("JAVA_SERVICE_FINANCIAL_PATH_GET_FORECAST", "/getFinancialForecastData")
PATH_GET_FINANCIAL_PERFORMANCE = config.get("JAVA_SERVICE_FINANCIAL_PATH_GET_PERFORMANCE",
                                            "/getFinancialPerformanceData")
PATH_GET_FINANCIAL_EX = config.get("JAVA_SERVICE_FINANCIAL_PATH_GET_EX", "/getFinancialExData")
PATH_GET_FINANCIAL_STATEMENT_DAILY = config.get("JAVA_SERVICE_FINANCIAL_PATH_GET_STATEMENT_DAILY",
                                                "/getFinancialStatementDailyData")

STOCK_ENDPOINT = config.get("JAVA_SERVICE_STOCK_ENDPOINT", "/stock")
PATH_GET_AUDIT_OPINION = config.get("JAVA_SERVICE_STOCK_PATH_GET_AUDIT_OPINION", "/getStockAuditData")
PATH_GET_FACTOR_RESTORED = config.get("JAVA_SERVICE_STOCK_PATH_GET_FACTOR_RESTORED", "/getFactorRestoredData")
MULTI_ENDPOINT = config.get("JAVA_SERVICE_KLINE_ENDPOINT", "/multi")
PATH_GET_FACTOR = config.get("JAVA_SERVICE_KLINE_PATH_GET_FACTOR", "/getFactor")



def _normalise_symbols(symbol: Optional[Union[str, List[str]]]) -> Optional[List[str]]:
    if symbol is None:
        return None
    if isinstance(symbol, list):
        return symbol
    return [symbol]

def _normalise_list(value: Optional[Union[str, List[str]]]) -> Optional[List[str]]:
    if value is None:
        return None
    if isinstance(value, list):
        return [item for item in value if item not in (None, "")]
    return [value] if value != "" else None


def _build_payload(
        *,
        symbol: Optional[Union[str, List[str]]] = None,
        fields: Optional[Union[str, List[str]]] = None,
        # 财务相关参数
        info_date: Optional[str] = None,
        end_quarter: Optional[str] = None,
        start_quarter: Optional[str] = None,
        date: Optional[str] = None,
        is_latest: Optional[bool] = None,
        start_date: Optional[str] = None,
        end_date: Optional[str] = None,
        market: Optional[str] = None,
        interim_type: Optional[str] = None,
        # 其他参数
        type: Optional[str] = None,
        factors: Optional[Union[str, List[str]]] = None,
        index_component: Optional[str] = None,
) -> Dict[str, Any]:
    payload: Dict[str, Any] = {}

    # 基础参数
    symbols = _normalise_symbols(symbol)
    if symbols is not None:
        payload["symbol"] = symbols
    if fields:
        payload["fields"] = fields

    # 财务参数
    if info_date is not None:
        payload["info_date"] = info_date
    if end_quarter is not None:
        payload["endQuarter"] = end_quarter
    if start_quarter is not None:
        payload["startQuarter"] = start_quarter
    if date is not None:
        payload["date"] = date
    if is_latest is not None:
        payload["isLatest"] = is_latest
    if start_date is not None:
        payload["startDate"] = start_date  # 注意驼峰命名
    if end_date is not None:
        payload["endDate"] = end_date  # 注意驼峰命名
    if market is not None:
        payload["market"] = market
    if interim_type is not None:
        payload["interimType"] = interim_type  # 注意驼峰命名

    # 其他参数
    if type is not None:
        payload["type"] = type
    if factors is not None:
        payload["factors"] = factors
    if index_component is not None:
        payload["indexComponent"] = index_component  # 注意驼峰命名

    return payload


def _reorder_fina_statement_columns(df: pd.DataFrame) -> pd.DataFrame:
    if df.empty:
        return df
    if {"symbol", "quarter"}.issubset(df.columns):
        cols = df.columns.tolist()
        priority_cols = ["symbol", "quarter"]
        other_cols = [col for col in cols if col not in priority_cols]
        return df[priority_cols + other_cols]
    if {"symbol", "date"}.issubset(df.columns):
        cols = df.columns.tolist()
        priority_cols = ["symbol", "date"]
        other_cols = [col for col in cols if col not in priority_cols]
        return df[priority_cols + other_cols]
    if "symbol" in df.columns:
        cols = df.columns.tolist()
        other_cols = [col for col in cols if col != "symbol"]
        return df[["symbol"] + other_cols]
    return df


def _validate_interim_type(interim_type: Optional[str]) -> str:
    if interim_type is None or interim_type == "":
        return "cumulative"
    if not isinstance(interim_type, str):
        raise ServiceError(
            code=ServiceErrorCode.REQUEST_PARAM_TYPE_ERROR,
            message=(
                f"[错误码 {ServiceErrorCode.REQUEST_PARAM_TYPE_ERROR}] interim_type 参数类型错误："
                f"应为 str，得到 {type(interim_type).__name__}"
            ),
        )
    interim_type_lower = interim_type.strip().lower()
    if interim_type_lower not in ["single", "cumulative"]:
        raise ServiceError(
            code=ServiceErrorCode.REQUEST_PARAM_INVALID,
            message=(
                f"[错误码 {ServiceErrorCode.REQUEST_PARAM_INVALID}] interim_type 只能为 single 或 cumulative，"
                f"当前值: {interim_type}"
            ),
        )
    return interim_type_lower


def get_fina_forecast(
        symbol: Optional[Union[str, List[str]]] = None,
        info_date: Optional[str] = None,
        end_quarter: Optional[str] = None,
        fields: Optional[Union[str, List[str]]] = None,
        **kwargs
) -> pd.DataFrame:
    """
    获取业绩预告
    """
    validate_extra_params(kwargs)
    # 验证参数类型
    params = {
        'symbol': symbol,
        'fields': fields
    }

    type_config = {
        'symbol': str,
        'fields': str
    }

    validated_params = validate_param_types(
        params,
        type_config,
        allowed_list_params=['symbol', 'fields']
    )

    # 验证symbol格式（空值会被正确处理）
    if validated_params['symbol'] is not None:
        validate_symbol_format(validated_params['symbol'])
        # 验证symbol列表中是否有重复值
        validate_no_duplicates(validated_params['symbol'], 'symbol')

    # 验证fields列表中是否有重复值（空值会被正确处理）
    if validated_params['fields'] is not None:
        validate_no_duplicates(validated_params['fields'], 'fields')

    # 验证info_date格式
    validated_info_date = validate_date_format(info_date, "info_date")

    # 验证end_quarter格式
    validated_end_quarter = validate_quarter_format(end_quarter, "end_quarter")

    payload = _build_payload(
        symbol=validated_params['symbol'],
        fields=validated_params['fields'],
        info_date=validated_info_date,
        end_quarter=validated_end_quarter,
    )

    df = fetch_dataframe(build_endpoint(FINA_ENDPOINT, PATH_GET_FINANCIAL_FORECAST), payload=payload)
    if not df.empty and {"symbol", "info_date"}.issubset(df.columns):
        cols = df.columns.tolist()
        priority_cols = ["symbol", "info_date"]
        other_cols = [col for col in cols if col not in priority_cols]
        df = df[priority_cols + other_cols]
    return df


def get_fina_performance(
        symbol: Optional[Union[str, List[str]]] = None,
        info_date: Optional[str] = None,
        end_quarter: Optional[str] = None,
        fields: Optional[Union[str, List[str]]] = None,
        **kwargs
) -> pd.DataFrame:
    """
    获取业绩快报
    """
    validate_extra_params(kwargs)
    # 验证参数类型
    params = {
        'symbol': symbol,
        'fields': fields
    }

    type_config = {
        'symbol': str,
        'fields': str
    }

    validated_params = validate_param_types(
        params,
        type_config,
        allowed_list_params=['symbol', 'fields']
    )

    # 验证symbol格式（空值会被正确处理）
    if validated_params['symbol'] is not None:
        validate_symbol_format(validated_params['symbol'])
        # 验证symbol列表中是否有重复值
        validate_no_duplicates(validated_params['symbol'], 'symbol')

    # 验证fields列表中是否有重复值（空值会被正确处理）
    if validated_params['fields'] is not None:
        validate_no_duplicates(validated_params['fields'], 'fields')

    # 添加日期处理逻辑
    if info_date:
        # 如果info_date非空，则将end_quarter设置为None
        end_quarter = None
    elif not info_date and not end_quarter:
        # 如果info_date和end_quarter均为空，则将info_date设置为当日日期
        info_date = datetime.now().strftime('%Y%m%d')

    # 验证info_date格式
    validated_info_date = validate_date_format(info_date, "info_date")

    # 验证end_quarter格式
    validated_end_quarter = validate_quarter_format(end_quarter, "end_quarter")
    payload = _build_payload(
        symbol=validated_params['symbol'],
        fields=validated_params['fields'],
        info_date=validated_info_date,
        end_quarter=validated_end_quarter,
    )

    df = fetch_dataframe(build_endpoint(FINA_ENDPOINT, PATH_GET_FINANCIAL_PERFORMANCE), payload=payload)
    if not df.empty and {"symbol", "info_date"}.issubset(df.columns):
        cols = df.columns.tolist()
        priority_cols = ["symbol", "info_date"]
        other_cols = [col for col in cols if col not in priority_cols]
        df = df[priority_cols + other_cols]
    return df


def get_fina_reports(
        symbol: Optional[Union[str, List[str]]] = None,
        fields: Optional[Union[str, List[str]]] = None,
        start_quarter: str = None,
        end_quarter: str = None,
        date: Optional[str] = None,
        is_latest: Optional[bool] = True,
        **kwargs
) -> pd.DataFrame:
    """
    获取季度财务报告

    Args:
        symbol: 股票代码列表
        fields: 返回字段列表
        start_quarter: 开始季度，必填，格式为YYYYqN（如2020q1）
        end_quarter: 结束季度，必填，格式为YYYYqN（如2025q1），与start_quarter间隔不得超过5年
        date: 日期参数，与start_quarter/end_quarter二选一
        is_latest: 是否只返回最新数据，默认为True
        **kwargs: 其他参数（会被验证）

    Returns:
        pd.DataFrame: 季度财务报告数据

    Raises:
        ServiceError: 当参数验证失败时抛出异常
    """
    validate_extra_params(kwargs)

    # 验证必填参数
    validate_not_empty(start_quarter, "start_quarter")
    validate_not_empty(end_quarter, "end_quarter")

    # 验证参数类型
    params = {
        'symbol': symbol,
        'fields': fields
    }

    type_config = {
        'symbol': str,
        'fields': str
    }

    validated_params = validate_param_types(
        params,
        type_config,
        allowed_list_params=['symbol', 'fields']
    )

    # 验证symbol格式（空值会被正确处理）
    if validated_params['symbol'] is not None:
        validate_symbol_format(validated_params['symbol'])
        # 验证symbol列表中是否有重复值
        validate_no_duplicates(validated_params['symbol'], 'symbol')

    # 对fields进行金融因子映射转换（新字段名转为旧字段名）
    if validated_params['fields'] is not None:
        # 确保fields是列表格式
        if isinstance(validated_params['fields'], str):
            fields_list = [validated_params['fields']]
        else:
            fields_list = validated_params['fields']

        # 更新validated_params中的fields为转换后的结果
        validated_params['fields'] = fields_list

        # 验证转换后的fields列表中是否有重复值（空值会被正确处理）
        validate_no_duplicates(validated_params['fields'], 'fields')

    # 验证季度格式
    validated_start_quarter = validate_quarter_format(start_quarter, "start_quarter")
    validated_end_quarter = validate_quarter_format(end_quarter, "end_quarter")

    # 验证季度范围
    validate_quarter_range(validated_start_quarter, validated_end_quarter)

    # 验证季度间隔不超过5年
    validate_quarter_interval(validated_start_quarter, validated_end_quarter, max_years=5)

    # 验证date格式
    validated_date = validate_date_format(date, "date")

    # 验证is_latest类型
    validated_is_latest = validate_bool_type(is_latest, "is_latest")

    # 新增：验证start_quarter、end_quarter和date参数的组合有效性
    validate_quarter_date_combination(start_quarter, end_quarter, date)

    payload = _build_payload(
        symbol=validated_params['symbol'],
        fields=validated_params['fields'],
        start_quarter=validated_start_quarter,
        end_quarter=validated_end_quarter,
        date=validated_date,
        is_latest=validated_is_latest,
    )

    df = fetch_dataframe(build_endpoint(FINA_ENDPOINT, PATH_GET_FINANCIAL_EX), payload=payload)
    if not df.empty and {"symbol", "quarter"}.issubset(df.columns):
        cols = df.columns.tolist()
        priority_cols = ["symbol", "quarter"]
        other_cols = [col for col in cols if col not in priority_cols]
        df = df[priority_cols + other_cols]
    return df


def get_financial_statement_daily(
        symbol: Optional[Union[str, List[str]]] = None,
        fields: Optional[Union[str, List[str]]] = None,
        start_date: Optional[str] = None,
        end_date: Optional[str] = None,
        market: Optional[str] = None,
        interim_type: Optional[str] = None,
        **kwargs
) -> pd.DataFrame:
    """
    获取财务报表日频数据
    返回的是 Parquet 格式文件，会自动转换为 DataFrame

    Args:
        symbol: 标的代码列表
        fields: 返回字段列表
        start_date: 开始日期，格式为 YYYYMMDD 或 YYYY-MM-DD
        end_date: 结束日期，格式为 YYYYMMDD 或 YYYY-MM-DD
        market: 市场类型，只能填 us 或 hk
        interim_type: 报表类型，只能填 single 或 cumulative
        **kwargs: 其他参数（会被验证）

    Returns:
        pd.DataFrame: 财务报表日频数据
    """
    validate_extra_params(kwargs)

    # 验证参数类型
    params = {
        'symbol': symbol,
        'fields': fields,
        'start_date': start_date,
        'end_date': end_date,
        'market': market,
        'interim_type': interim_type
    }

    type_config = {
        'symbol': str,
        'fields': str,
        'start_date': str,
        'end_date': str,
        'market': str,
        'interim_type': str
    }

    validated_params = validate_param_types(
        params,
        type_config,
        allowed_list_params=['symbol', 'fields']
    )

    # 仅验证 symbol 列表无重复（本接口为港美股，不校验 A 股 symbol 格式）
    if validated_params['symbol'] is not None:
        validate_no_duplicates(validated_params['symbol'], 'symbol')

    # 验证fields列表中是否有重复值（空值会被正确处理）
    if validated_params['fields'] is not None:
        validate_no_duplicates(validated_params['fields'], 'fields')

    # 验证日期格式
    validated_start_date = validate_date_format(start_date, "start_date")
    validated_end_date = validate_date_format(end_date, "end_date")

    # 验证日期范围
    if validated_start_date and validated_end_date:
        validate_date_range(validated_start_date, validated_end_date)

    # 验证market参数（必须非空，且只能是 us 或 hk）
    if market is None or market == "":
        raise ServiceError(
            code=ServiceErrorCode.REQUEST_PARAM_EMPTY,
            message=f"[错误码 {ServiceErrorCode.REQUEST_PARAM_EMPTY}] market参数不能为空，只能填us或hk"
        )

    if not isinstance(market, str):
        raise ServiceError(
            code=ServiceErrorCode.REQUEST_PARAM_TYPE_ERROR,
            message=f"[错误码 {ServiceErrorCode.REQUEST_PARAM_TYPE_ERROR}] market参数类型错误：应为str类型，得到{type(market).__name__}类型"
        )

    market_lower = market.strip().lower()
    if market_lower not in ["us", "hk"]:
        raise ServiceError(
            code=ServiceErrorCode.REQUEST_PARAM_INVALID,
            message=f"[错误码 {ServiceErrorCode.REQUEST_PARAM_INVALID}] market参数错误，只能填us或hk，当前值为: {market}"
        )

    # 验证interim_type参数（必须非空，且只能是 single 或 cumulative）
    if interim_type is None or interim_type == "":
        raise ServiceError(
            code=ServiceErrorCode.REQUEST_PARAM_EMPTY,
            message=f"[错误码 {ServiceErrorCode.REQUEST_PARAM_EMPTY}] interimType参数不能为空，只能填single或cumulative"
        )

    if not isinstance(interim_type, str):
        raise ServiceError(
            code=ServiceErrorCode.REQUEST_PARAM_TYPE_ERROR,
            message=f"[错误码 {ServiceErrorCode.REQUEST_PARAM_TYPE_ERROR}] interimType参数类型错误：应为str类型，得到{type(interim_type).__name__}类型"
        )

    interim_type_lower = interim_type.strip().lower()
    if interim_type_lower not in ["single", "cumulative"]:
        raise ServiceError(
            code=ServiceErrorCode.REQUEST_PARAM_INVALID,
            message=f"[错误码 {ServiceErrorCode.REQUEST_PARAM_INVALID}] interimType参数错误，只能填single或cumulative，当前值为: {interim_type}"
        )

    # 构建payload，注意Java端期望的字段名是startDate和endDate（驼峰命名）
    payload = _build_payload(
        symbol=validated_params['symbol'],
        fields=validated_params['fields'],
        extra={
            **({"startDate": validated_start_date} if validated_start_date is not None else {}),
            **({"endDate": validated_end_date} if validated_end_date is not None else {}),
            "market": market_lower,
            "interimType": interim_type_lower,
        },
    )

    # 调用接口，返回的是 Parquet 文件，fetch_dataframe 会自动处理
    df = fetch_dataframe(build_endpoint(FINA_ENDPOINT, PATH_GET_FINANCIAL_STATEMENT_DAILY), payload=payload)

    # 如果返回的DataFrame不为空，尝试调整列顺序（如果存在symbol和date列）
    if not df.empty:
        if "symbol" in df.columns and "date" in df.columns:
            cols = df.columns.tolist()
            priority_cols = ["symbol", "date"]
            other_cols = [col for col in cols if col not in priority_cols]
            df = df[priority_cols + other_cols]
        elif "symbol" in df.columns:
            cols = df.columns.tolist()
            priority_cols = ["symbol"]
            other_cols = [col for col in cols if col not in priority_cols]
            df = df[priority_cols + other_cols]

    return df

def get_audit_opinion(
    symbol: Optional[Union[str, List[str]]] = None,
    start_quarter: Optional[str] = None,
    end_quarter: Optional[str] = None,
    market: Optional[str] = "cn",
    fields: Optional[Union[str, List[str]]] = None,
    **kwargs
) -> pd.DataFrame:
    # 1. 检查额外参数
    validate_extra_params(kwargs)

    # 2. 验证参数类型
    params = {
        'symbol': symbol,
        'market': market,
        'fields': fields
    }

    type_config = {
        'symbol': str,
        'market': str,
        'fields': str
    }

    validated_params = validate_param_types(
        params,
        type_config,
        allowed_list_params=['symbol', 'fields']
    )

    # 3. 验证symbol格式（空值会被正确处理）
    if validated_params['symbol'] is not None:
        validate_symbol_format(validated_params['symbol'])
        # 验证symbol列表中是否有重复值
        validate_no_duplicates(validated_params['symbol'], 'symbol')

    # 4. 验证fields列表中是否有重复值（空值会被正确处理）
    if validated_params['fields'] is not None:
        validate_no_duplicates(validated_params['fields'], 'fields')

    # 5. 验证市场参数
    if validated_params['market'] is not None:
        validated_params['market'] = validate_stock_info_market(validated_params['market'])

    # 6. 验证季度格式
    validated_start_quarter = validate_quarter_format(start_quarter, "start_quarter")
    validated_end_quarter = validate_quarter_format(end_quarter, "end_quarter")

    # 7. 验证季度范围
    validate_quarter_range(validated_start_quarter, validated_end_quarter)

    payload = {"market": validated_params['market']}
    symbols = _normalise_list(validated_params['symbol'])
    if symbols is not None:
        payload["symbol"] = symbols
    if validated_start_quarter:
        payload["startQuarter"] = validated_start_quarter
    if validated_end_quarter:
        payload["endQuarter"] = validated_end_quarter
    if validated_params['fields']:
        payload["fields"] = validated_params['fields']
    df = fetch_dataframe(build_endpoint(STOCK_ENDPOINT, PATH_GET_AUDIT_OPINION), payload=payload)
    if not df.empty and {"symbol", "quarter"}.issubset(df.columns):
        cols = df.columns.tolist()
        priority_cols = ["symbol", "quarter"]
        other_cols = [col for col in cols if col not in priority_cols]
        df = df[priority_cols + other_cols]
    return df

def get_adj_factor(
    symbol: Optional[Union[str, List[str]]] = None,
    start_date: Optional[str] = None,
    end_date: Optional[str] = None,
    fields: Optional[Union[str, List[str]]] = None,
    **kwargs
) -> pd.DataFrame:
    # 1. 检查额外参数
    validate_extra_params(kwargs)

    # 2. 验证参数类型
    params = {
        'symbol': symbol,
        'fields': fields
    }

    type_config = {
        'symbol': str,
        'fields': str
    }

    validated_params = validate_param_types(
        params,
        type_config,
        allowed_list_params=['symbol', 'fields']
    )

    # 3. 验证symbol格式（空值会被正确处理）
    if validated_params['symbol'] is not None:
        validate_symbol_format(validated_params['symbol'])
        # 验证symbol列表中是否有重复值
        validate_no_duplicates(validated_params['symbol'], 'symbol')

    # 4. 验证fields列表中是否有重复值（空值会被正确处理）
    if validated_params['fields'] is not None:
        validate_no_duplicates(validated_params['fields'], 'fields')

    # 5. 验证日期格式
    validated_start_date = validate_date_format(start_date, "start_date")
    validated_end_date = validate_date_format(end_date, "end_date")

    # 6. 验证日期范围
    validate_date_range(validated_start_date, validated_end_date)

    payload = {}
    symbols = _normalise_list(validated_params['symbol'])
    if symbols is not None:
        payload["symbol"] = symbols
    if validated_start_date:
        payload["startDate"] = validated_start_date
    if validated_end_date:
        payload["endDate"] = validated_end_date
    if validated_params['fields']:
        payload["fields"] = validated_params['fields']
    df = fetch_dataframe(build_endpoint("/factor", PATH_GET_FACTOR_RESTORED), payload=payload)
    if not df.empty and {"symbol", "ex_date"}.issubset(df.columns):
        cols = df.columns.tolist()
        priority_cols = ["symbol", "ex_date"]
        other_cols = [col for col in cols if col not in priority_cols]
        df = df[priority_cols + other_cols]
    return df

def get_factor(
        symbol: Union[str, List[str]] = "",
        start_date: str = "",
        end_date: str = "",
        type: Optional[str] = "stock",
        factors: Union[str, List[str]] = None,
        index_component: Optional[str] = "",
        **kwargs
) -> pd.DataFrame:

    validate_extra_params(kwargs)
    # 验证必填参数
    validate_not_empty(start_date, "start_date")
    validate_not_empty(end_date, "end_date")
    validate_not_empty(factors, "factors")

    # 验证参数类型
    params = {
        'symbol': symbol,
        'factors': factors
    }

    type_config = {
        'symbol': str,
        'factors': str
    }

    validated_params = validate_param_types(
        params,
        type_config,
        allowed_list_params=['symbol', 'factors']
    )

    # 验证symbol格式（根据type类型）
    if validated_params['symbol'] is not None:
        # 验证symbol列表中是否有重复值
        validate_no_duplicates(validated_params['symbol'], 'symbol')

        # 根据type类型验证symbol格式
        validated_type = validate_factor_type(type, "type")
        if validated_type == "stock":
            validate_symbol_format(validated_params['symbol'])
        elif validated_type == "future":
            validate_future_symbol_format(validated_params['symbol'])

    # 验证factors列表中是否有重复值
    if validated_params['factors'] is not None:
        # 确保factors是列表格式
        if isinstance(validated_params['factors'], str):
            factors_list = [validated_params['factors']]
        else:
            factors_list = validated_params['factors']

        validated_params['factors'] = factors_list

        validate_no_duplicates(validated_params['factors'], 'factors')

    # 验证日期格式
    validated_start_date = validate_date_format(start_date, "start_date")
    validated_end_date = validate_date_format(end_date, "end_date")

    # 验证日期范围
    validate_date_range(validated_start_date, validated_end_date)
    # 验证日期间隔不能超过5年
    validate_date_interval(validated_start_date, validated_end_date, max_years=5)

    # 验证type参数
    validated_type = validate_factor_type(type, "type")

    # 如果index_component是旧版的，则提供转换以兼容
    if index_component == "100":
        index_component = "000300"
    elif index_component == "010":
        index_component = "000905"
    elif index_component == "001":
        index_component = "000852"
    elif index_component == "000":
        index_component = "000985"

    # 验证index_component参数
    validated_index_component = validate_indicator(index_component, "indexComponent")

    if validated_index_component == "000985":
        validated_index_component = ""

    payload = {"type": validated_type}
    symbols = _normalise_symbols(validated_params['symbol'] if validated_params['symbol'] != [""] else None)
    if symbols is not None:
        payload["symbol"] = symbols
    if validated_start_date:
        payload["startDate"] = validated_start_date
    if validated_end_date:
        payload["endDate"] = validated_end_date
    if validated_params['factors']:
        payload["factors"] = validated_params['factors']
    if validated_index_component:
        payload["indexComponent"] = validated_index_component

    df = fetch_dataframe(build_endpoint(MULTI_ENDPOINT, PATH_GET_FACTOR), payload=payload)

    # 如果返回的数据包含嵌套的 JSON 结构，需要展开
    if not df.empty:
        # 检查是否数据在某个列中（如 'data' 列）
        if 'data' in df.columns and isinstance(df['data'].iloc[0], list):
            # 将嵌套的列表展开为新的 DataFrame
            expanded_data = []
            for item in df['data']:
                if isinstance(item, list):
                    expanded_data.extend(item)

            if expanded_data:
                df = pd.DataFrame(expanded_data)

    # 如果有index_component列则丢弃
    if 'index_component' in df.columns:
        df = df.drop(columns=['index_component'], errors='ignore')

    if not df.empty and {"symbol", "date"}.issubset(df.columns):
        df = df.sort_values(by=["symbol", "date"], ascending=[True, False]).reset_index(drop=True)

    return df