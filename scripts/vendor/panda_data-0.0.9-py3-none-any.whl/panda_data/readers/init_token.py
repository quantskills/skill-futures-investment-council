from __future__ import annotations

import json
import os
from hashlib import md5
from typing import Optional

from panda_data.config import get_config
from panda_data.exceptions import ServiceError
from panda_data.utils.common_utils import build_endpoint, find_project_root
from panda_data.client import init as init_client
from panda_data.transport.http import HTTPClient, HTTPClientConfig

config = get_config()
BASE_ENDPOINT = config.get("JAVA_SERVICE_USER_ENDPOINT", "/dataUser")
PATH_GET_ABNORMAL = config.get("JAVA_SERVICE_USER_PATH_LOGIN", "/login")
USERNAME = config.get("DEFAULT_USERNAME")
PASSWORD = config.get("DEFAULT_PASSWORD")
BASE_URL = config.get("JAVA_SERVICE_BASE_URL")


def init_token(username: Optional[str] = USERNAME, password: Optional[str] = PASSWORD,
               base_url: Optional[str] = BASE_URL) -> str:
    # 检查用户名和密码是否为空
    if not username or not password or not base_url:
        raise ServiceError("username / password / base_url 不能为空")

    # 构造完整的base_url
    login_base_url = base_url.rstrip("/") + "/pandaData"

    # 直接使用HTTPClient发送登录请求（登录接口不需要token，只需要用户名密码）
    http_config = HTTPClientConfig(
        base_url=login_base_url,
        username=username,
        password=password,
    )
    http_client = HTTPClient(http_config)

    # 构造请求载荷
    payload = {
        "username": username,
        "password": md5(password.encode('utf-8')).hexdigest()
    }

    # 发送登录请求
    try:
        raw_response = http_client.request(
            method="POST",
            endpoint=build_endpoint(BASE_ENDPOINT, PATH_GET_ABNORMAL),
            payload=payload
        )

        # 检查响应是否包含错误码
        if isinstance(raw_response, dict) and raw_response.get("code") not in ["200", 200]:
            # 提取错误码和消息
            error_code = raw_response.get("code")
            error_message = raw_response.get("message", "未知错误")
            raise ServiceError(f"[错误码 {error_code} : {error_message}]")

        # 提取token：可能是字符串，也可能在data字段中
        result = None
        if isinstance(raw_response, str):
            result = raw_response
        elif isinstance(raw_response, dict):
            # 尝试从data字段提取
            if "data" in raw_response:
                result = raw_response["data"]
            elif "token" in raw_response:
                result = raw_response["token"]
            else:
                # 如果整个响应就是token（某些情况下）
                result = raw_response
    except Exception as e:
        raise ServiceError(f"登录失败: {e}")
    finally:
        http_client.close()

    # 确保result是字符串
    if isinstance(result, dict):
        # 如果还是dict，尝试转换为字符串或提取值
        result = str(result)
    if not result or not isinstance(result, str):
        raise ServiceError("登录失败：无法获取有效的token")

    project_root = find_project_root(os.path.dirname(__file__))
    user_info_file_path = os.path.join(project_root, "user.json")
    # 删除文件
    try:
        os.remove(user_info_file_path)
    except Exception:
        pass  # 忽略删除失败的情况（文件可能不存在）

    # 结果写入到项目根目录下的文件中， 文件名是f"user_{USERNAME}.json"
    if result and isinstance(result, str):
        # 准备一个map（字典），包含 username, token, base_url 字段
        token_map = {
            "username": username,
            "token": result,
            "base_url": base_url
        }

        # 写入数据到文件
        try:
            with open(user_info_file_path, 'w', encoding='utf-8') as json_file:
                json.dump(token_map, json_file, ensure_ascii=False, indent=4)
        except Exception as e:
            raise ServiceError(f"写入用户信息失败: {str(e)}")

        # 登录成功后，初始化客户端（显式非本地模式，走鉴权）
        try:
            init_client(
                username=username,
                password=password,
                base_url=base_url,
            )
        except Exception as e:
            # 如果初始化失败，不影响token保存，但记录警告
            print(f"警告：客户端初始化失败: {e}")

    return result

