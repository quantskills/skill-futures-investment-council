"""
配置模块，用于加载和管理配置信息
支持从配置文件和环境变量导入，环境变量优先级更高
"""
import os
import yaml
import logging
from pathlib import Path

# 获取logger
try:
    from panda_data.logger.config import logger
except ImportError:
    # 如果无法导入logger，创建一个基本的logger
    logging.basicConfig(level=logging.INFO)
    logger = logging.getLogger("config")


# 初始化配置变量config = None

def load_config():
    """加载配置文件，并从环境变量更新配置"""
    global config

    config = {}

    # 日志配置 Logging
    config["LOG_LEVEL"] = os.getenv("LOG_LEVEL", "DEBUG")
    config["log_file"] = os.getenv("LOG_FILE", "logs/panda_data.log")
    config["log_rotation"] = os.getenv("LOG_ROTATION", "1 MB")
    config["LOG_PATH"] = os.getenv("LOG_PATH", "~/log")

    # HTTP service integration
    config["DEFAULT_USERNAME"] = os.getenv("DEFAULT_USERNAME", "")
    config["DEFAULT_PASSWORD"] = os.getenv("DEFAULT_PASSWORD", "")

    config["HTTP_SERVICE_BASE_URL"] = os.getenv("HTTP_SERVICE_BASE_URL")
    config["HTTP_TIMEOUT"] = os.getenv("HTTP_TIMEOUT", "300")
    config["HTTP_MAX_RETRIES"] = os.getenv("HTTP_MAX_RETRIES", "3")
    config["HTTP_VERIFY_SSL"] = os.getenv("HTTP_VERIFY_SSL", "true")
    config["HTTP_PROXY_TYPE"] = os.getenv("HTTP_PROXY_TYPE")  # "http" or "https"
    config["HTTP_PROXY_HOST"] = os.getenv("HTTP_PROXY_HOST")
    config["HTTP_PROXY_PORT"] = os.getenv("HTTP_PROXY_PORT")
    config["HTTP_PROXY_USERNAME"] = os.getenv("HTTP_PROXY_USERNAME")
    config["HTTP_PROXY_PASSWORD"] = os.getenv("HTTP_PROXY_PASSWORD")
    config["HTTP_USE_GZIP"] = os.getenv("HTTP_USE_GZIP", "false")
    config["HTTP_DATA_FIELD"] = os.getenv("HTTP_DATA_FIELD", "data")
    config["HTTP_ABNORMAL_ENDPOINT"] = os.getenv("HTTP_ABNORMAL_ENDPOINT", "/abnormal")

    # Legacy HTTP service config (for backward compatibility)
    # config["JAVA_SERVICE_BASE_URL"] = os.getenv("JAVA_SERVICE_BASE_URL", "http://pandadata.pandaai.online")
    config["JAVA_SERVICE_BASE_URL"] = os.getenv("JAVA_SERVICE_BASE_URL", "http://pandadata.pandaaiquant.com")
    config["JAVA_SERVICE_TIMEOUT"] = os.getenv("JAVA_SERVICE_TIMEOUT", "15")
    config["JAVA_SERVICE_MAX_POOL_SIZE"] = os.getenv("JAVA_SERVICE_MAX_POOL_SIZE", "10")
    config["JAVA_SERVICE_MAX_RETRIES"] = os.getenv("JAVA_SERVICE_MAX_RETRIES", "3")
    config["JAVA_SERVICE_BACKOFF_FACTOR"] = os.getenv("JAVA_SERVICE_BACKOFF_FACTOR", "0.3")
    config["JAVA_SERVICE_VERIFY_SSL"] = os.getenv("JAVA_SERVICE_VERIFY_SSL", "true")
    config["JAVA_SERVICE_DATA_FIELD"] = os.getenv("JAVA_SERVICE_DATA_FIELD", "data")
    config["JAVA_SERVICE_ABNORMAL_ENDPOINT"] = os.getenv("JAVA_SERVICE_ABNORMAL_ENDPOINT", "/abnormal")

    config["JAVA_SERVICE_CALENDAR_ENDPOINT"] = os.getenv("JAVA_SERVICE_CALENDAR_ENDPOINT", "/tradeCalendar")
    config["JAVA_SERVICE_CALENDAR_PATH_GET_TRADE_CALENDAR_DATA"] = os.getenv(
        "JAVA_SERVICE_CALENDAR_PATH_GET_TRADE_CALENDAR_DATA", "/getTradeCalendarData")
    config["JAVA_SERVICE_CALENDAR_PATH_GET_PREVIOUS_NTH_TRADING_DAY"] = os.getenv(
        "JAVA_SERVICE_CALENDAR_PATH_GET_PREVIOUS_NTH_TRADING_DAY", "/getPreviousNthTradingDay")
    config["JAVA_SERVICE_CALENDAR_PATH_GET_LATEST_TRADING_DAY"] = os.getenv(
        "JAVA_SERVICE_CALENDAR_PATH_GET_LATEST_TRADING_DAY", "/getLatestTradingDay")

    config["JAVA_SERVICE_ABNORMAL_ENDPOINT"] = os.getenv("JAVA_SERVICE_ABNORMAL_ENDPOINT", "/abnormal")
    config["JAVA_SERVICE_ABNORMAL_PATH_GET_ABNORMAL_DATA"] = os.getenv("JAVA_SERVICE_ABNORMAL_PATH_GET_ABNORMAL_DATA",
                                                                       "/getAbnormalData")
    config["JAVA_SERVICE_ABNORMAL_PATH_GET_ABNORMAL_DETAIL"] = os.getenv(
        "JAVA_SERVICE_ABNORMAL_PATH_GET_ABNORMAL_DETAIL", "/getAbnormalDetailData")

    config["JAVA_SERVICE_BUY_BACK_ENDPOINT"] = os.getenv("JAVA_SERVICE_BUY_BACK_ENDPOINT", "/buyback")
    config["JAVA_SERVICE_BUY_BACK_PATH_GET_BUY_BACK_DATA"] = os.getenv("JAVA_SERVICE_BUY_BACK_PATH_GET_BUY_BACK_DATA",
                                                                       "/getBuyBackData")

    config["JAVA_SERVICE_CONCEPT_ENDPOINT"] = os.getenv("JAVA_SERVICE_CONCEPT_ENDPOINT", "/concept")
    config["JAVA_SERVICE_CONCEPT_PATH_GET_CONCEPT_LIST"] = os.getenv("JAVA_SERVICE_CONCEPT_PATH_GET_CONCEPT_LIST",
                                                                     "/getConceptData")
    config["JAVA_SERVICE_CONCEPT_PATH_GET_CONCEPT_STOCK"] = os.getenv("JAVA_SERVICE_CONCEPT_PATH_GET_CONCEPT_STOCK",
                                                                      "/getConceptStockData")

    config["JAVA_SERVICE_FINANCIAL_ENDPOINT"] = os.getenv("JAVA_SERVICE_FINANCIAL_ENDPOINT", "/financial")
    config["JAVA_SERVICE_FINANCIAL_PATH_GET_FORECAST"] = os.getenv("JAVA_SERVICE_FINANCIAL_PATH_GET_FORECAST",
                                                                   "/getFinancialForecastData")
    config["JAVA_SERVICE_FINANCIAL_PATH_GET_PERFORMANCE"] = os.getenv("JAVA_SERVICE_FINANCIAL_PATH_GET_PERFORMANCE",
                                                                      "/getFinancialPerformanceData")
    config["JAVA_SERVICE_FINANCIAL_PATH_GET_EX"] = os.getenv("JAVA_SERVICE_FINANCIAL_PATH_GET_EX",
                                                             "/getFinancialExData")
    config["JAVA_SERVICE_FINANCIAL_PATH_GET_FINA_STATEMENT"] = os.getenv(
        "JAVA_SERVICE_FINANCIAL_PATH_GET_FINA_STATEMENT", "/getFinaStatement")
    config["JAVA_SERVICE_FINANCIAL_PATH_GET_FINA_EX"] = os.getenv(
        "JAVA_SERVICE_FINANCIAL_PATH_GET_FINA_EX", "/getFinaEx")

    config["JAVA_SERVICE_FUND_ENDPOINT"] = os.getenv("JAVA_SERVICE_FUND_ENDPOINT", "/fund")
    config["JAVA_SERVICE_FUND_PATH_GET_ALL_FUNDS"] = os.getenv("JAVA_SERVICE_FUND_PATH_GET_ALL_FUNDS", "/getAllFunds")
    config["JAVA_SERVICE_FUND_PATH_GET_FUND_PRO"] = os.getenv("JAVA_SERVICE_FUND_PATH_GET_FUND_PRO",
                                                              "/getFundPortfolioData")
    config["JAVA_SERVICE_FUND_PATH_GET_FUND_NAV"] = os.getenv("JAVA_SERVICE_FUND_PATH_GET_FUND_NAV", "/getFundNavData")

    config["JAVA_SERVICE_FUTURE_ENDPOINT"] = os.getenv("JAVA_SERVICE_FUTURE_ENDPOINT", "/future")
    config["JAVA_SERVICE_FUTURE_PATH_GET_FUTURE_LIST"] = os.getenv("JAVA_SERVICE_FUTURE_PATH_GET_FUTURE_LIST",
                                                                   "/getFutureList")
    config["JAVA_SERVICE_FUTURE_PATH_GET_FACTOR_POST"] = os.getenv("JAVA_SERVICE_FUTURE_PATH_GET_FACTOR_POST",
                                                                   "/getFutureMarketPostData")
    config["JAVA_SERVICE_FUTURE_PATH_FUTURE_DOMINANT"] = os.getenv("JAVA_SERVICE_FUTURE_PATH_FUTURE_DOMINANT",
                                                                   "/getFutureDominantData")
    config["JAVA_SERVICE_FUTURE_PATH_GET_SYMBOL_POSI_RANK"] = os.getenv("JAVA_SERVICE_FUTURE_PATH_GET_SYMBOL_POSI_RANK",
                                                                        "/getFutureSymbolPosiRankData")
    config["JAVA_SERVICE_TICK_PATH_FUTURE_TICK"] = os.getenv("JAVA_SERVICE_TICK_PATH_FUTURE_TICK", "/getFutureTickData")
    config["JAVA_SERVICE_FUTURE_PATH_FUTURE_NETPOSI_RANK"] = os.getenv("JAVA_SERVICE_FUTURE_PATH_FUTURE_NETPOSI_RANK",
                                                                       "/getFutureNetposiRankData")
    config["JAVA_SERVICE_FUTURE_PATH_FUTURE_NET_FLOW"] = os.getenv("JAVA_SERVICE_FUTURE_PATH_FUTURE_NET_FLOW",
                                                                   "/getFutureNetFlowData")
    config["JAVA_SERVICE_FUTURE_PATH_GET_BROKER_GRADE"] = os.getenv("JAVA_SERVICE_FUTURE_PATH_GET_BROKER_GRADE",
                                                                    "/getBrokerGradeData")
    config["JAVA_SERVICE_FUTURE_PATH_GET_BROKER_NET_MARGIN"] = os.getenv(
        "JAVA_SERVICE_FUTURE_PATH_GET_BROKER_NET_MARGIN", "/getBrokerNetMarginData")
    config["JAVA_SERVICE_FUTURE_PATH_GET_BROKER_NET_MARGIN_CHANGE"] = os.getenv(
        "JAVA_SERVICE_FUTURE_PATH_GET_BROKER_NET_MARGIN_CHANGE", "/getBrokerNetMarginChangeData")
    config["JAVA_SERVICE_FUTURE_PATH_GET_BROKER_TOTAL_MARGIN"] = os.getenv(
        "JAVA_SERVICE_FUTURE_PATH_GET_BROKER_TOTAL_MARGIN", "/getBrokerTotalMarginData")
    config["JAVA_SERVICE_FUTURE_PATH_GET_FUTURE_BASIS"] = os.getenv("JAVA_SERVICE_FUTURE_PATH_GET_FUTURE_BASIS",
                                                                    "/getFutureBasisData")
    config["JAVA_SERVICE_FUTURE_PATH_GET_FUTURE_WR"] = os.getenv("JAVA_SERVICE_FUTURE_PATH_GET_FUTURE_WR",
                                                                 "/getFutureWRData")
    config["JAVA_SERVICE_FUTURE_PATH_GET_FUTURE_LS_RATIO"] = os.getenv("JAVA_SERVICE_FUTURE_PATH_GET_FUTURE_LS_RATIO",
                                                                       "/getFutureLSRatioData")
    config["JAVA_SERVICE_FUTURE_PATH_GET_FUTURE_CONTRACT_RANK"] = os.getenv(
        "JAVA_SERVICE_FUTURE_PATH_GET_FUTURE_CONTRACT_RANK", "/getFutureContractRankData")
    config["JAVA_SERVICE_FUTURE_PATH_GET_FUTURE_NET_CAP_CHANGE"] = os.getenv(
        "JAVA_SERVICE_FUTURE_PATH_GET_FUTURE_NET_CAP_CHANGE", "/getFutureNetCapChangeData")
    config["JAVA_SERVICE_FUTURE_PATH_GET_FUTURE_TERM_STRUCTURE"] = os.getenv(
        "JAVA_SERVICE_FUTURE_PATH_GET_FUTURE_TERM_STRUCTURE", "/getFutureTermStructureData")
    config["JAVA_SERVICE_FUTURE_PATH_GET_FUTURE_INVENTORY"] = os.getenv("JAVA_SERVICE_FUTURE_PATH_GET_FUTURE_INVENTORY",
                                                                        "/getFutureInventoryData")
    config["JAVA_SERVICE_FUTURE_PATH_GET_FUTURE_RESEARCH_REPORT"] = os.getenv(
        "JAVA_SERVICE_FUTURE_PATH_GET_FUTURE_RESEARCH_REPORT", "/getFutureResearchReportData")
    config["JAVA_SERVICE_FUTURE_PATH_DOWNLOAD_FUTURE_RESEARCH_REPORT"] = os.getenv(
        "JAVA_SERVICE_FUTURE_PATH_DOWNLOAD_FUTURE_RESEARCH_REPORT", "/downloadFutureResearchReport")
    config["JAVA_SERVICE_FUTURE_PATH_GET_FUTURE_SYMBOL_OI_VALUE"] = os.getenv(
        "JAVA_SERVICE_FUTURE_PATH_GET_FUTURE_SYMBOL_OI_VALUE", "/getFutureSymbolOiValueData")
    config["JAVA_SERVICE_FUTURE_PATH_GET_FUTURE_BROKER_POSITION"] = os.getenv(
        "JAVA_SERVICE_FUTURE_PATH_GET_FUTURE_BROKER_POSITION", "/getFutureBrokerPositionData")
    config["JAVA_SERVICE_FUTURE_PATH_GET_FUTURE_BROKER_PROFIT"] = os.getenv(
        "JAVA_SERVICE_FUTURE_PATH_GET_FUTURE_BROKER_PROFIT", "/getFutureBrokerProfitData")
    config["JAVA_SERVICE_FUTURE_PATH_GET_FUTURE_NONBROKER_NET_OI"] = os.getenv(
        "JAVA_SERVICE_FUTURE_PATH_GET_FUTURE_NONBROKER_NET_OI", "/getFutureNonbrokerNetOiData")
    config["JAVA_SERVICE_FUTURE_PATH_GET_FUTURE_CROSS_TERM_ARBITRAGE"] = os.getenv(
        "JAVA_SERVICE_FUTURE_PATH_GET_FUTURE_CROSS_TERM_ARBITRAGE", "/getFutureCrossTermArbitrageData")
    config["JAVA_SERVICE_FUTURE_PATH_GET_FUTURE_FREE_SPREAD"] = os.getenv(
        "JAVA_SERVICE_FUTURE_PATH_GET_FUTURE_FREE_SPREAD", "/getFutureFreeSpreadData")
    config["JAVA_SERVICE_FUTURE_PATH_GET_FUTURE_FREE_RATIO"] = os.getenv(
        "JAVA_SERVICE_FUTURE_PATH_GET_FUTURE_FREE_RATIO", "/getFutureFreeRatioData")
    config["JAVA_SERVICE_FUTURE_PATH_GET_FUTURE_DOMINANT_CORRELATION_MATRIX"] = os.getenv(
        "JAVA_SERVICE_FUTURE_PATH_GET_FUTURE_DOMINANT_CORRELATION_MATRIX", "/getFutureDominantCorrelationMatrixData")

    config["JAVA_SERVICE_INDEX_ENDPOINT"] = os.getenv("JAVA_SERVICE_INDEX_ENDPOINT", "/index")
    config["JAVA_SERVICE_INDEX_PATH_GET_SYMBOL"] = os.getenv("JAVA_SERVICE_INDEX_PATH_GET_SYMBOL",
                                                             "/getIndexSymbolData")
    config["JAVA_SERVICE_INDEX_PATH_GET_INDICATOR"] = os.getenv("JAVA_SERVICE_INDEX_PATH_GET_INDICATOR",
                                                                "/getIndexIndicatorData")
    config["JAVA_SERVICE_INDEX_PATH_GET_WEIGHTS"] = os.getenv("JAVA_SERVICE_INDEX_PATH_GET_WEIGHTS",
                                                              "/getIndexWeightsData")
    config["JAVA_SERVICE_INDEX_PATH_GET_INDEX_DETAIL_QH"] = os.getenv("JAVA_SERVICE_INDEX_PATH_GET_INDEX_DETAIL_QH",
                                                                      "/getIndexDetailQH")
    config["JAVA_SERVICE_INDEX_PATH_GET_INDEX_LEADING_QH"] = os.getenv("JAVA_SERVICE_INDEX_PATH_GET_INDEX_LEADING_QH",
                                                                       "/getIndexLeadingQH")

    config["JAVA_SERVICE_INDUSTRY_ENDPOINT"] = os.getenv("JAVA_SERVICE_INDUSTRY_ENDPOINT", "/industry")
    config["JAVA_SERVICE_INDUSTRY_PATH_GET_STOCK"] = os.getenv("JAVA_SERVICE_INDUSTRY_PATH_GET_STOCK",
                                                               "/getIndustryStockData")
    config["JAVA_SERVICE_INDUSTRY_PATH_GET_LIST"] = os.getenv("JAVA_SERVICE_INDUSTRY_PATH_GET_LIST", "/getIndustryList")
    config["JAVA_SERVICE_INDUSTRY_PATH_GET_STOCK_INDUSTRY"] = os.getenv("JAVA_SERVICE_INDUSTRY_PATH_GET_STOCK_INDUSTRY",
                                                                        "/getStockIndustry")

    config["JAVA_SERVICE_KLINE_ENDPOINT"] = os.getenv("JAVA_SERVICE_KLINE_ENDPOINT", "/multi")
    config["JAVA_SERVICE_KLINE_PATH_GET_STOCK_DETAIL"] = os.getenv("JAVA_SERVICE_KLINE_PATH_GET_STOCK_DETAIL",
                                                                   "/getStockDetail")
    config["JAVA_SERVICE_KLINE_PATH_GET_HK_DETAIL"] = os.getenv("JAVA_SERVICE_KLINE_PATH_GET_HK_DETAIL",
                                                                "/getHkDetail")
    config["JAVA_SERVICE_KLINE_PATH_GET_US_DETAIL"] = os.getenv("JAVA_SERVICE_KLINE_PATH_GET_US_DETAIL",
                                                                "/getUsDetail")
    config["JAVA_SERVICE_KLINE_PATH_GET_MARKET_DATA"] = os.getenv("JAVA_SERVICE_KLINE_PATH_GET_MARKET_DATA",
                                                                  "/getMultiMarketData")
    config["JAVA_SERVICE_KLINE_PATH_GET_STOCK_DAILY"] = os.getenv("JAVA_SERVICE_KLINE_PATH_GET_STOCK_DAILY",
                                                                  "/getStockDaily")
    config["JAVA_SERVICE_KLINE_PATH_GET_INDEX_DAILY"] = os.getenv("JAVA_SERVICE_KLINE_PATH_GET_INDEX_DAILY",
                                                                  "/getIndexDaily")
    config["JAVA_SERVICE_KLINE_PATH_GET_FUTURE_DAILY"] = os.getenv("JAVA_SERVICE_KLINE_PATH_GET_FUTURE_DAILY",
                                                                   "/getFutureDaily")
    config["JAVA_SERVICE_KLINE_PATH_GET_STOCK_DAILY_POST"] = os.getenv("JAVA_SERVICE_KLINE_PATH_GET_STOCK_DAILY_POST",
                                                                       "/getStockDailyPost")
    config["JAVA_SERVICE_KLINE_PATH_GET_STOCK_DAILY_PRE"] = os.getenv("JAVA_SERVICE_KLINE_PATH_GET_STOCK_DAILY_PRE",
                                                                      "/getStockDailyPre")
    config["JAVA_SERVICE_KLINE_PATH_GET_STOCK_RT_DAILY"] = os.getenv("JAVA_SERVICE_KLINE_PATH_GET_STOCK_RT_DAILY",
                                                                     "/getStockRtDaily")
    config["JAVA_SERVICE_KLINE_PATH_GET_MARKET_MIN_DATA"] = os.getenv("JAVA_SERVICE_KLINE_PATH_GET_MARKET_MIN_DATA",
                                                                      "/getMultiMarketMinData")
    config["JAVA_SERVICE_KLINE_PATH_GET_STOCK_MIN"] = os.getenv("JAVA_SERVICE_KLINE_PATH_GET_STOCK_MIN",
                                                                "/getStockMin")
    config["JAVA_SERVICE_KLINE_PATH_GET_INDEX_MIN"] = os.getenv("JAVA_SERVICE_KLINE_PATH_GET_INDEX_MIN",
                                                                "/getIndexMin")
    config["JAVA_SERVICE_KLINE_PATH_GET_FUTURE_MIN"] = os.getenv("JAVA_SERVICE_KLINE_PATH_GET_FUTURE_MIN",
                                                                 "/getFutureMin")
    config["JAVA_SERVICE_KLINE_PATH_GET_STOCK_RT_MIN"] = os.getenv("JAVA_SERVICE_KLINE_PATH_GET_STOCK_RT_MIN",
                                                                   "/getStockRtMin")
    config["JAVA_SERVICE_KLINE_PATH_GET_FACTOR"] = os.getenv("JAVA_SERVICE_KLINE_PATH_GET_FACTOR", "/getFactor")

    config["JAVA_SERVICE_SECURITIES_MARGIN_ENDPOINT"] = os.getenv("JAVA_SERVICE_SECURITIES_MARGIN_ENDPOINT",
                                                                  "/stock")

    config["JAVA_SERVICE_SECURITIES_MARGIN_PATH_GET_MARGIN"] = os.getenv(
        "JAVA_SERVICE_SECURITIES_MARGIN_PATH_GET_MARGIN",
        "/getSecuritiesMarginData")

    config["JAVA_SERVICE_STOCK_CONNECT_ENDPOINT"] = os.getenv("JAVA_SERVICE_STOCK_CONNECT_ENDPOINT",
                                                              "/stock")
    config["JAVA_SERVICE_STOCK_CONNECT_PATH_GET_STOCK_CONNECT_DATA"] = os.getenv(
        "JAVA_SERVICE_STOCK_CONNECT_PATH_GET_STOCK_CONNECT_DATA",
        "/getStockConnectData")

    config["JAVA_SERVICE_STOCK_ENDPOINT"] = os.getenv("JAVA_SERVICE_STOCK_ENDPOINT", "/stock")
    config["JAVA_SERVICE_STOCK_PATH_GET_FLOW"] = os.getenv("JAVA_SERVICE_STOCK_PATH_GET_FLOW", "/getStockFlowData")
    config["JAVA_SERVICE_STOCK_PATH_GET_AUDIT_OPINION"] = os.getenv("JAVA_SERVICE_STOCK_PATH_GET_AUDIT_OPINION",
                                                                    "/getStockAuditData")
    config["JAVA_SERVICE_STOCK_PATH_GET_INVESTOR_ACTIVITIES"] = os.getenv(
        "JAVA_SERVICE_STOCK_PATH_GET_INVESTOR_ACTIVITIES", "/getStockInvestorData")
    config["JAVA_SERVICE_STOCK_PATH_GET_RESTRICTED_DETAILS"] = os.getenv(
        "JAVA_SERVICE_STOCK_PATH_GET_RESTRICTED_DETAILS", "/getStockRestrictedData")
    config["JAVA_SERVICE_STOCK_PATH_GET_STOCK_CASH_DIVIDEND"] = os.getenv(
        "JAVA_SERVICE_STOCK_PATH_GET_STOCK_CASH_DIVIDEND", "/getStockCashDividendData")
    config["JAVA_SERVICE_STOCK_PATH_GET_STOCK_DIVIDEND_INFO"] = os.getenv(
        "JAVA_SERVICE_STOCK_PATH_GET_STOCK_DIVIDEND_INFO", "/getStockDividendInfoData")
    config["JAVA_SERVICE_STOCK_PATH_GET_STOCK_SPLIT_INFO"] = os.getenv(
        "JAVA_SERVICE_STOCK_PATH_GET_STOCK_SPLIT_INFO", "/getStockSplitInfoData")
    config["JAVA_SERVICE_STOCK_PATH_GET_STOCK_DIVIDEND_AMOUNT"] = os.getenv(
        "JAVA_SERVICE_STOCK_PATH_GET_STOCK_DIVIDEND_AMOUNT", "/getStockDividendAmountData")
    config["JAVA_SERVICE_STOCK_PATH_GET_STOCK_PRIVATE_PLACEMENT"] = os.getenv(
        "JAVA_SERVICE_STOCK_PATH_GET_STOCK_PRIVATE_PLACEMENT", "/getStockPrivatePlacementData")
    config["JAVA_SERVICE_STOCK_PATH_GET_STOCK_ALLOTMENT"] = os.getenv(
        "JAVA_SERVICE_STOCK_PATH_GET_STOCK_ALLOTMENT", "/getStockAllotmentData")
    config["JAVA_SERVICE_STOCK_PATH_GET_HOLDER_NUMBER"] = os.getenv("JAVA_SERVICE_STOCK_PATH_GET_HOLDER_NUMBER",
                                                                    "/getStockHolderNumberData")
    config["JAVA_SERVICE_STOCK_PATH_GET_MAIN_SHAREHOLDER"] = os.getenv("JAVA_SERVICE_STOCK_PATH_GET_MAIN_SHAREHOLDER",
                                                                       "/getStockMainHolderData")
    config["JAVA_SERVICE_STOCK_PATH_GET_SPECIAL_TREATMENT"] = os.getenv("JAVA_SERVICE_STOCK_PATH_GET_SPECIAL_TREATMENT",
                                                                        "/getStockSpecialTreatmentData")
    config["JAVA_SERVICE_STOCK_PATH_GET_FLOW_1M"] = os.getenv("JAVA_SERVICE_STOCK_PATH_GET_FLOW_1M",
                                                              "/getStockFlowMinData")
    config["JAVA_SERVICE_STOCK_PATH_GET_BLOCK_TRADE"] = os.getenv("JAVA_SERVICE_STOCK_PATH_GET_BLOCK_TRADE",
                                                                  "/getStockBlockTradeData")
    config["JAVA_SERVICE_STOCK_PATH_GET_FACTOR_RESTORED"] = os.getenv("JAVA_SERVICE_STOCK_PATH_GET_FACTOR_RESTORED",
                                                                      "/getFactorRestoredData")
    config["JAVA_SERVICE_STOCK_PATH_GET_SHARES"] = os.getenv("JAVA_SERVICE_STOCK_PATH_GET_SHARES", "/getStockShareData")
    config["JAVA_SERVICE_STOCK_PATH_GET_TRADING_STOCK_LIST"] = os.getenv(
        "JAVA_SERVICE_STOCK_PATH_GET_TRADING_STOCK_LIST", "/getTradingStockList")
    config["JAVA_SERVICE_STOCK_PATH_GET_STOCK_CUMU_GUARANTEE"] = os.getenv(
        "JAVA_SERVICE_STOCK_PATH_GET_STOCK_CUMU_GUARANTEE", "/getStockCumuGuaranteeData")
    config["JAVA_SERVICE_STOCK_PATH_GET_STOCK_EQUITY_PLEDGE"] = os.getenv(
        "JAVA_SERVICE_STOCK_PATH_GET_STOCK_EQUITY_PLEDGE", "/getStockEquityPledgeData")
    config["JAVA_SERVICE_STOCK_PATH_GET_STOCK_EQUITY_PLEDGE_STAT"] = os.getenv(
        "JAVA_SERVICE_STOCK_PATH_GET_STOCK_EQUITY_PLEDGE_STAT", "/getStockEquityPledgeStatData")
    config["JAVA_SERVICE_STOCK_PATH_GET_STOCK_RELA_PARTY_TRANS"] = os.getenv(
        "JAVA_SERVICE_STOCK_PATH_GET_STOCK_RELA_PARTY_TRANS", "/getStockRelaPartyTransData")
    config["JAVA_SERVICE_STOCK_PATH_GET_STOCK_SHAREHOLDER_TRADING_PLAN"] = os.getenv(
        "JAVA_SERVICE_STOCK_PATH_GET_STOCK_SHAREHOLDER_TRADING_PLAN", "/getStockShareholderTradingPlanData")
    config["JAVA_SERVICE_STOCK_PATH_GET_STOCK_EQUITY_ILLEGAL"] = os.getenv(
        "JAVA_SERVICE_STOCK_PATH_GET_STOCK_EQUITY_ILLEGAL", "/getStockEquityIllegalData")
    config["JAVA_SERVICE_STOCK_PATH_GET_STOCK_EQUITY_NATURE"] = os.getenv(
        "JAVA_SERVICE_STOCK_PATH_GET_STOCK_EQUITY_NATURE", "/getStockEquityNatureData")
    config["JAVA_SERVICE_STOCK_PATH_GET_STOCK_EQUITY_PLACARD"] = os.getenv(
        "JAVA_SERVICE_STOCK_PATH_GET_STOCK_EQUITY_PLACARD", "/getStockEquityPlacardData")

    config["JAVA_SERVICE_STOCK_PATH_GET_STOCK_MARKET_EVENT"] = os.getenv(
        "JAVA_SERVICE_STOCK_PATH_GET_STOCK_MARKET_EVENT", "/getStockMarketEvent")
    config["JAVA_SERVICE_STOCK_PATH_GET_STOCK_MARKET_ACTIVITY"] = os.getenv(
        "JAVA_SERVICE_STOCK_PATH_GET_STOCK_MARKET_ACTIVITY", "/getStockMarketActivity")
    config["JAVA_SERVICE_STOCK_PATH_GET_STOCK_MEETING_EVENT"] = os.getenv(
        "JAVA_SERVICE_STOCK_PATH_GET_STOCK_MEETING_EVENT", "/getStockMeetingEvent")
    config["JAVA_SERVICE_STOCK_PATH_GET_STOCK_MEETING_ACTIVITY"] = os.getenv(
        "JAVA_SERVICE_STOCK_PATH_GET_STOCK_MEETING_ACTIVITY", "/getStockMeetingActivity")
    config["JAVA_SERVICE_STOCK_PATH_GET_STOCK_DIVIDEND_EVENT"] = os.getenv(
        "JAVA_SERVICE_STOCK_PATH_GET_STOCK_DIVIDEND_EVENT", "/getStockDividendEvent")
    config["JAVA_SERVICE_STOCK_PATH_GET_STOCK_DIVIDEND_ACTIVITY"] = os.getenv(
        "JAVA_SERVICE_STOCK_PATH_GET_STOCK_DIVIDEND_ACTIVITY", "/getStockDividendActivity")
    config["JAVA_SERVICE_STOCK_PATH_GET_STOCK_IR_EVENT"] = os.getenv(
        "JAVA_SERVICE_STOCK_PATH_GET_STOCK_IR_EVENT", "/getStockIrEvent")
    config["JAVA_SERVICE_STOCK_PATH_GET_STOCK_IR_ACTIVITY"] = os.getenv(
        "JAVA_SERVICE_STOCK_PATH_GET_STOCK_IR_ACTIVITY", "/getStockIrActivity")
    config["JAVA_SERVICE_STOCK_PATH_GET_STOCK_FINANCIAL_EVENT"] = os.getenv(
        "JAVA_SERVICE_STOCK_PATH_GET_STOCK_FINANCIAL_EVENT", "/getStockFinancialEvent")
    config["JAVA_SERVICE_STOCK_PATH_GET_STOCK_FINANCIAL_ACTIVITY"] = os.getenv(
        "JAVA_SERVICE_STOCK_PATH_GET_STOCK_FINANCIAL_ACTIVITY", "/getStockFinancialActivity")
    config["JAVA_SERVICE_STOCK_PATH_GET_STOCK_INVESTOR_CONCENTRATION"] = os.getenv(
        "JAVA_SERVICE_STOCK_PATH_GET_STOCK_INVESTOR_CONCENTRATION", "/getStockInvestorConcentration")
    config["JAVA_SERVICE_STOCK_PATH_GET_STOCK_INVESTOR_CENTRALIZATION"] = os.getenv(
        "JAVA_SERVICE_STOCK_PATH_GET_STOCK_INVESTOR_CENTRALIZATION", "/getStockInvestorCentralization")
    config["JAVA_SERVICE_STOCK_PATH_GET_STOCK_TOP20_CONCENTRATION"] = os.getenv(
        "JAVA_SERVICE_STOCK_PATH_GET_STOCK_TOP20_CONCENTRATION", "/getStockTop20Concentration")
    config["JAVA_SERVICE_STOCK_PATH_GET_STOCK_TOP20_CENTRALIZATION"] = os.getenv(
        "JAVA_SERVICE_STOCK_PATH_GET_STOCK_TOP20_CENTRALIZATION", "/getStockTop20Centralization")
    config["JAVA_SERVICE_STOCK_PATH_GET_STOCK_INSIDER_TRADE"] = os.getenv(
        "JAVA_SERVICE_STOCK_PATH_GET_STOCK_INSIDER_TRADE", "/getStockInsiderTrade")
    config["JAVA_SERVICE_STOCK_PATH_GET_STOCK_INSIDER_TRANSACTION"] = os.getenv(
        "JAVA_SERVICE_STOCK_PATH_GET_STOCK_INSIDER_TRANSACTION", "/getStockInsiderTransaction")
    config["JAVA_SERVICE_STOCK_PATH_GET_STOCK_SHAREHOLDER_HOLDING"] = os.getenv(
        "JAVA_SERVICE_STOCK_PATH_GET_STOCK_SHAREHOLDER_HOLDING", "/getStockShareholderHolding")
    config["JAVA_SERVICE_STOCK_PATH_GET_STOCK_SHAREHOLDER_REPORT"] = os.getenv(
        "JAVA_SERVICE_STOCK_PATH_GET_STOCK_SHAREHOLDER_REPORT", "/getStockShareholderReport")
    config["JAVA_SERVICE_STOCK_PATH_GET_STOCK_INVESTOR_RANKING"] = os.getenv(
        "JAVA_SERVICE_STOCK_PATH_GET_STOCK_INVESTOR_RANKING", "/getStockInvestorRanking")
    config["JAVA_SERVICE_STOCK_PATH_GET_STOCK_INVESTOR_LEADERBOARD"] = os.getenv(
        "JAVA_SERVICE_STOCK_PATH_GET_STOCK_INVESTOR_LEADERBOARD", "/getStockInvestorLeaderboard")
    config["JAVA_SERVICE_STOCK_PATH_GET_STOCK_MKTFIN_INDICATOR"] = os.getenv(
        "JAVA_SERVICE_STOCK_PATH_GET_STOCK_MKTFIN_INDICATOR", "/getStockMktfinIndicator")
    config["JAVA_SERVICE_STOCK_PATH_GET_STOCK_MKTFIN_METRIC"] = os.getenv(
        "JAVA_SERVICE_STOCK_PATH_GET_STOCK_MKTFIN_METRIC", "/getStockMktfinMetric")
    config["JAVA_SERVICE_STOCK_PATH_GET_STOCK_INDUSTRY_MEDIAN"] = os.getenv(
        "JAVA_SERVICE_STOCK_PATH_GET_STOCK_INDUSTRY_MEDIAN", "/getStockIndustryMedian")
    config["JAVA_SERVICE_STOCK_PATH_GET_STOCK_SECTOR_MEDIAN"] = os.getenv(
        "JAVA_SERVICE_STOCK_PATH_GET_STOCK_SECTOR_MEDIAN", "/getStockSectorMedian")
    config["JAVA_SERVICE_STOCK_PATH_GET_STOCK_PV_INDICATOR"] = os.getenv(
        "JAVA_SERVICE_STOCK_PATH_GET_STOCK_PV_INDICATOR", "/getStockPvIndicator")
    config["JAVA_SERVICE_STOCK_PATH_GET_STOCK_PV_METRIC"] = os.getenv(
        "JAVA_SERVICE_STOCK_PATH_GET_STOCK_PV_METRIC", "/getStockPvMetric")
    config["JAVA_SERVICE_STOCK_PATH_GET_STOCK_NCYCL_CONSENSUS"] = os.getenv(
        "JAVA_SERVICE_STOCK_PATH_GET_STOCK_NCYCL_CONSENSUS", "/getStockNcyclConsensus")
    config["JAVA_SERVICE_STOCK_PATH_GET_STOCK_NCYCL_ESTIMATE"] = os.getenv(
        "JAVA_SERVICE_STOCK_PATH_GET_STOCK_NCYCL_ESTIMATE", "/getStockNcyclEstimate")
    config["JAVA_SERVICE_STOCK_PATH_GET_STOCK_RECOMMENDATION_CONSENSUS"] = os.getenv(
        "JAVA_SERVICE_STOCK_PATH_GET_STOCK_RECOMMENDATION_CONSENSUS", "/getStockRecommendationConsensus")
    config["JAVA_SERVICE_STOCK_PATH_GET_STOCK_RECOMMENDATION_ESTIMATE"] = os.getenv(
        "JAVA_SERVICE_STOCK_PATH_GET_STOCK_RECOMMENDATION_ESTIMATE", "/getStockRecommendationEstimate")
    config["JAVA_SERVICE_STOCK_PATH_GET_STOCK_OPERATING_INDICATOR"] = os.getenv(
        "JAVA_SERVICE_STOCK_PATH_GET_STOCK_OPERATING_INDICATOR", "/getStockOperatingIndicator")
    config["JAVA_SERVICE_STOCK_PATH_GET_STOCK_OPERATING_METRIC"] = os.getenv(
        "JAVA_SERVICE_STOCK_PATH_GET_STOCK_OPERATING_METRIC", "/getStockOperatingMetric")

    config["JAVA_SERVICE_INDEX_PATH_GET_INDEX_COMPONENT"] = os.getenv(
        "JAVA_SERVICE_INDEX_PATH_GET_INDEX_COMPONENT", "/getIndexComponent")
    config["JAVA_SERVICE_INDEX_PATH_GET_INDEX_CONSTITUENT"] = os.getenv(
        "JAVA_SERVICE_INDEX_PATH_GET_INDEX_CONSTITUENT", "/getIndexConstituent")
    config["JAVA_SERVICE_STOCK_PATH_GET_INV_BRIEF_QA"] = os.getenv("JAVA_SERVICE_STOCK_PATH_GET_INV_BRIEF_QA",
                                                                   "/getInvBriefQAData")
    config["JAVA_SERVICE_STOCK_PATH_GET_INV_BRIEF_DETAIL"] = os.getenv("JAVA_SERVICE_STOCK_PATH_GET_INV_BRIEF_DETAIL",
                                                                       "/getInvBriefDetailData")

    config["JAVA_SERVICE_TICK_ENDPOINT"] = os.getenv("JAVA_SERVICE_TICK_ENDPOINT", "/tick")
    config["JAVA_SERVICE_TICK_PATH_HK_TICK"] = os.getenv("JAVA_SERVICE_TICK_PATH_HK_TICK", "/getStockHKTickData")

    config["JAVA_SERVICE_HK_ENDPOINT"] = os.getenv("JAVA_SERVICE_HK_ENDPOINT", "/hkMarket")
    config["JAVA_SERVICE_HK_PATH_STOCK"] = os.getenv("JAVA_SERVICE_HK_PATH_STOCK", "/getStockMarketHKData")
    config["JAVA_SERVICE_HK_PATH_STOCK_MIN"] = os.getenv("JAVA_SERVICE_HK_PATH_STOCK_MIN", "/getStockMarketHKMinData")

    config["JAVA_SERVICE_US_ENDPOINT"] = os.getenv("JAVA_SERVICE_US_ENDPOINT", "/usMarket")
    config["JAVA_SERVICE_US_PATH_STOCK"] = os.getenv("JAVA_SERVICE_US_PATH_STOCK", "/getStockMarketUSData")
    config["JAVA_SERVICE_US_PATH_STOCK_MIN"] = os.getenv("JAVA_SERVICE_US_PATH_STOCK_MIN", "/getStockMarketUSMinData")

    config["JAVA_SERVICE_MACRO_ENDPOINT"] = os.getenv("JAVA_SERVICE_MACRO_ENDPOINT", "/macro")
    config["JAVA_SERVICE_MACRO_PATH_GET_MACRO_CAL"] = os.getenv("JAVA_SERVICE_MACRO_PATH_GET_MACRO_CAL",
                                                                "/getMacroCalData")
    config["JAVA_SERVICE_MACRO_PATH_GET_MACRO_CAL_CONFIG"] = os.getenv("JAVA_SERVICE_MACRO_PATH_GET_MACRO_CAL_CONFIG",
                                                                       "/getMacroCalConfig")
    config["JAVA_SERVICE_MACRO_PATH_GET_MACRO_CAL_INFO"] = os.getenv("JAVA_SERVICE_MACRO_PATH_GET_MACRO_CAL_INFO",
                                                                     "/getMacroCalInfo")
    config["JAVA_SERVICE_MACRO_PATH_GET_MACRO_DETAIL"] = os.getenv("JAVA_SERVICE_MACRO_PATH_GET_MACRO_DETAIL",
                                                                   "/getMacroDetail")

    config["JAVA_SERVICE_USER_ENDPOINT"] = os.getenv("JAVA_SERVICE_USER_ENDPOINT", "/dataUser")
    config["JAVA_SERVICE_USER_PATH_LOGIN"] = os.getenv("JAVA_SERVICE_USER_PATH_LOGIN", "/login")
    config["JAVA_SERVICE_TICK_USER_ENDPOINT"] = os.getenv("JAVA_SERVICE_TICK_USER_ENDPOINT", "/tickUser")
    config["JAVA_SERVICE_TICK_USER_PATH_LOGIN"] = os.getenv("JAVA_SERVICE_TICK_USER_PATH_LOGIN", "/login")
    config["JAVA_SERVICE_FUTURE_PATH_GET_FUTURE_SAT_PROFIT_RAMKING"] = os.getenv(
        "JAVA_SERVICE_FUTURE_PATH_GET_FUTURE_SAT_PROFIT_RAMKING", "/getFutureSatProfitData")
    config["JAVA_SERVICE_FUTURE_PATH_GET_FUTURE_SAT_LOSS_RANKING"] = os.getenv(
        "JAVA_SERVICE_FUTURE_PATH_GET_FUTURE_SAT_LOSS_RANKING", "/getFutureSatLossData")
    config['JAVA_SERVICE_FUTURE_PATH_GET_FUTURE_POSITION_BUILDING_PROCESS'] = os.getenv(
        "JAVA_SERVICE_FUTURE_PATH_GET_FUTURE_POSITION_BUILDING_PROCESS", "/getFutureBuildingProcessData")
    config['JAVA_SERVICE_FUTURE_PATH_GET_FUTURE_CAP_VALUE'] = os.getenv("JAVA_SERVICE_FUTURE_PATH_GET_FUTURE_CAP_VALUE",
                                                                        "/getFutureCapValueData")
    config['JAVA_SERVICE_FUTURE_PATH_GET_FUTURE_SEAT_MATCHING'] = os.getenv(
        "JAVA_SERVICE_FUTURE_PATH_GET_FUTURE_SEAT_MATCHING", "/getFutureSeatMatchingData")
    config['JAVA_SERVICE_FUTURE_PATH_GET_FUTURE_RATIO_OF_VIRTUAL_TO_REAL_POSITIONS'] = os.getenv(
        "JAVA_SERVICE_FUTURE_PATH_GET_FUTURE_RATIO_OF_VIRTUAL_TO_REAL_POSITIONS", "/getFutureRatioVitualRealData")
    config['JAVA_SERVICE_FUTURE_PATH_GET_FUTURE_SPOT_PROFIT'] = os.getenv(
        "JAVA_SERVICE_FUTURE_PATH_GET_FUTURE_SPOT_PROFIT", "/getFutureSpotProfitData")
    config['JAVA_SERVICE_FUTURE_PATH_GET_FUTURE_SPOT_TRADER_QUOTATION'] = os.getenv(
        "JAVA_SERVICE_FUTURE_PATH_GET_FUTURE_SPOT_TRADER_QUOTATION", "/getFutureTraderQuotationData")

    # Option service endpoints
    config["JAVA_SERVICE_OPTION_PATH_GET_OPTION_DETAIL"] = os.getenv(
        "JAVA_SERVICE_OPTION_PATH_GET_OPTION_DETAIL", "/getOptionDetailData")
    config["JAVA_SERVICE_OPTION_PATH_GET_OPTION_UNDERLYING_DETAIL"] = os.getenv(
        "JAVA_SERVICE_OPTION_PATH_GET_OPTION_UNDERLYING_DETAIL", "/getOptionUnderlyingDetailData")
    config["JAVA_SERVICE_OPTION_PATH_GET_OPTION_MARKET_DATA"] = os.getenv(
        "JAVA_SERVICE_OPTION_PATH_GET_OPTION_MARKET_DATA", "/getOptionMarketData")
    config["JAVA_SERVICE_OPTION_PATH_GET_OPTION_IMPLIED_VOLATILITY"] = os.getenv(
        "JAVA_SERVICE_OPTION_PATH_GET_OPTION_IMPLIED_VOLATILITY", "/getOptionImpliedVolatilityData")
    config["JAVA_SERVICE_OPTION_PATH_GET_OPTION_UDERLYING_VOLATILITY"] = os.getenv(
        "JAVA_SERVICE_OPTION_PATH_GET_OPTION_HISTORICAL_VOLATILITY",
        "/getOptionUnderlyingVolatilityData")
    config["JAVA_SERVICE_STOCK_PATH_GET_STOCK_DISCLOSURE_DATE"] = os.getenv(
        "JAVA_SERVICE_STOCK_PATH_GET_STOCK_DISCLOSURE_DATE",
        "/getStockDisclosureDateData")
    config["JAVA_SERVICE_STOCK_PATH_GET_STOCK_STATUS_OVER_ALLOTMENT"] = os.getenv(
        "JAVA_SERVICE_STOCK_PATH_GET_STOCK_STATUS_OVER_ALLOTMENT",
        "/getStockStatusOverAllotmentData")
    config["JAVA_SERVICE_STOCK_PATH_GET_STOCK_LITIGATION_ARBITRATION"] = os.getenv(
        "JAVA_SERVICE_STOCK_PATH_GET_STOCK_LITIGATION_ARBITRATION",
        "/getStockLitigationArbitrationData")
    config["JAVA_SERVICE_STOCK_PATH_GET_STOCK_CSRC_APPROVAL"] = os.getenv(
        "JAVA_SERVICE_STOCK_PATH_GET_STOCK_CSRC_APPROVAL",
        "/getStockCsrcApprovalData")
    config["JAVA_SERVICE_STOCK_PATH_GET_STOCK_COMPETITOR_INFORMATION"] = os.getenv(
        "JAVA_SERVICE_STOCK_PATH_GET_STOCK_COMPETITOR_INFORMATION",
        "/getStockCompetitorInformationData")
    config["JAVA_SERVICE_STOCK_PATH_GET_STOCK_INTERMEDIARY_INFORMATION"] = os.getenv(
        "JAVA_SERVICE_STOCK_PATH_GET_STOCK_INTERMEDIARY_INFORMATION",
        "/getStockIntermediaryInformationData")
    config["JAVA_SERVICE_STOCK_PATH_GET_MATERIAL_CONTRACT"] = os.getenv("JAVA_SERVICE_STOCK_PATH_GET_MATERIAL_CONTRACT",
                                                                        "/getStockMaterialContractData")
    config["JAVA_SERVICE_OPTION_PATH_GET_OPTION_EXERCISE"] = os.getenv(
        "JAVA_SERVICE_OPTION_PATH_GET_OPTION_EXERCISE",
        "/getOptionExerciseData")
    config["JAVA_SERVICE_OPTION_PATH_GET_OPTION_SPOT_MARKET"] = os.getenv(
        "JAVA_SERVICE_OPTION_PATH_GET_OPTION_SPOT_MARKET",
        "/getOptionSpotMarketData")
    config["JAVA_SERVICE_OPTION_PATH_GET_OPTION_RISK_INDICATORS"] = os.getenv(
        "JAVA_SERVICE_OPTION_PATH_GET_OPTION_RISK_INDICATORS",
        "/getOptionRiskIndicatorsData")
    config["JAVA_SERVICE_OPTION_PATH_GET_OPTION_STATIC"] = os.getenv(
        "JAVA_SERVICE_OPTION_PATH_GET_OPTION_STATIC",
        "/getOptionStaticData")

    # WebSocket 实时行情
    # 网关需命中 /pandaData/ws/tick 才路由到 tick 服务；与 HTTP 登录端口可不同
    config["WS_LIVE_MARKET_URL"] = os.getenv("WS_LIVE_MARKET_URL", "ws://127.0.0.1:8180/pandaData/ws/tick")
    # 为 True 时 TickStreamClient 可不 init_token、不带头直连（与 skip_auth 参数二选一即可）
    config["WS_LIVE_MARKET_SKIP_AUTH"] = os.getenv("WS_LIVE_MARKET_SKIP_AUTH", "").lower() in (
        "1",
        "true",
        "yes",
    )

    # 打包前可加入 panda_data_local_config 模块覆盖配置（如 LOCAL_MODE=True），便于无鉴权本地调用
    try:
        import panda_data_local_config as _local
        if getattr(_local, "JAVA_SERVICE_BASE_URL", None):
            config["JAVA_SERVICE_BASE_URL"] = _local.JAVA_SERVICE_BASE_URL
    except ImportError:
        pass

    return config


def get_config():
    """
    获取配置对象，如果配置未加载则先加载配置

    Returns:
        dict: 配置信息字典
    """
    global config
    if config is None:
        config = load_config()
    return config


# 初始加载配置
try:
    config = load_config()
    # logger.info(f"初始化配置成功: {config}")  # 已禁用初始化配置日志
except Exception as e:
    logger.error(f"初始化配置失败: {str(e)}")
    # 不在初始化时抛出异常，留到实际使用时再处理
